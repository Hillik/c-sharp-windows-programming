﻿using System;

public class Box
{
    // 成員變數 (屬性)
    private double Width { get; set; }
    private double Height { get; set; }
    private double Length { get; set; }

    // 建構子
    public Box(double width, double height, double length)
    {
        Width = width;
        Height = height;
        Length = length;
    }

    // 成員方法：計算體積
    public double Volume()
    {
        return Width * Height * Length;
    }

    // 成員方法：計算總表面積
    public double Area()
    {
        return 2 * (Width * Length + Width * Height + Height * Length);
    }

    // 範例用法 (可選，用於測試)
    public static void Main(string[] args)
    {
        Box myBox = new Box(10.0, 5.0, 8.0);
        Console.WriteLine($"盒子的體積: {myBox.Volume()}");
        Console.WriteLine($"盒子的總表面積: {myBox.Area()}");

        Box anotherBox = new Box(3.5, 2.0, 4.0);
        Console.WriteLine($"另一個盒子的體積: {anotherBox.Volume()}");
        Console.WriteLine($"另一個盒子的總表面積: {anotherBox.Area()}");
    }
}