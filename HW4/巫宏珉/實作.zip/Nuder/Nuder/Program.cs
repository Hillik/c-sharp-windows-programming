using System;
using System.Windows.Forms;
using ArrayRandomSortApp;

namespace ArrayRandomSortApp // <--- This namespace
{
    static class Program
    {
        /// <summary>
        /// ���ε{�����D�n�i�J�I�C
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1()); // <--- Form1 should be in MyWinFormsApp namespace
        }
    }
}