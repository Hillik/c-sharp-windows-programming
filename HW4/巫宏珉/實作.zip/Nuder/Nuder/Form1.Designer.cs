﻿namespace ArrayRandomSortApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGenerateSort = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            this.SuspendLayout();
            //
            // btnGenerateSort
            //
            this.btnGenerateSort.Location = new System.Drawing.Point(50, 30);
            this.btnGenerateSort.Name = "btnGenerateSort";
            this.btnGenerateSort.Size = new System.Drawing.Size(120, 40);
            this.btnGenerateSort.TabIndex = 0;
            this.btnGenerateSort.Text = "生成並排序陣列";
            this.btnGenerateSort.UseVisualStyleBackColor = true;
            this.btnGenerateSort.Click += new System.EventHandler(this.btnGenerateSort_Click);
            //
            // lblResult
            //
            this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle; // 增加邊框以便觀察範圍
            this.lblResult.Location = new System.Drawing.Point(50, 90);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(200, 80); // 調整大小以顯示多行
            this.lblResult.TabIndex = 1;
            this.lblResult.Text = ""; // 初始清空
            //
            // Form1
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 200);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.btnGenerateSort);
            this.Name = "Form1";
            this.Text = "陣列亂數與排序";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGenerateSort;
        private System.Windows.Forms.Label lblResult;
    }
}