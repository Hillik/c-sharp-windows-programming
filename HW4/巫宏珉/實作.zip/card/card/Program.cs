﻿using System;

// PhoneList 類別
public class PhoneList
{
    public string Homephone { get; set; }
    public string BusinessPhone { get; set; }
    public string CellPhone { get; set; }

    // 建構子
    public PhoneList(string home = null, string business = null, string cell = null)
    {
        Homephone = home;
        BusinessPhone = business;
        CellPhone = cell;
    }

    // 取得所有電話號碼的字串表示
    public string GetAllPhones()
    {
        string phones = "";
        if (!string.IsNullOrEmpty(Homephone))
        {
            phones += "住家電話: " + Homephone + "\n";
        }
        if (!string.IsNullOrEmpty(BusinessPhone))
        {
            phones += "公司電話: " + BusinessPhone + "\n";
        }
        if (!string.IsNullOrEmpty(CellPhone))
        {
            phones += "手機號碼: " + CellPhone + "\n";
        }
        return phones.Trim(); // 移除最後的換行符
    }
}

// Cards 類別
public class Cards
{
    public string Name { get; set; }
    public string Occupation { get; set; }
    public int Age { get; set; }
    public string Email { get; set; }
    public PhoneList Phone { get; set; } // 參考 PhoneList 類別的實例

    // 建構子
    public Cards(string name, string occupation, int age, string email, PhoneList phone)
    {
        Name = name;
        Occupation = occupation;
        Age = age;
        Email = email;
        Phone = phone;
    }

    // 取得名片資料的方法
    public string GetCard()
    {
        string cardInfo = $"姓名: {Name}\n";
        cardInfo += $"職業: {Occupation}\n";
        cardInfo += $"年齡: {Age}\n";
        cardInfo += $"Email: {Email}\n";

        if (Phone != null)
        {
            cardInfo += "--- 電話資訊 ---\n";
            cardInfo += Phone.GetAllPhones();
        }
        return cardInfo;
    }

    // 範例用法 (可選，用於測試)
    public static void Main(string[] args)
    {
        // 建立 PhoneList 物件
        PhoneList johnPhones = new PhoneList("02-12345678", "02-98765432", "0912345678");
        PhoneList janePhones = new PhoneList(null, "07-55555555", "0987654321");
        PhoneList emptyPhones = new PhoneList(); // 沒有電話號碼

        // 建立 Cards 物件
        Cards card1 = new Cards("John Doe", "軟體工程師", 30, "john.doe@example.com", johnPhones);
        Cards card2 = new Cards("Jane Smith", "專案經理", 35, "jane.smith@example.com", janePhones);
        Cards card3 = new Cards("Peter Chen", "學生", 20, "peter.chen@example.com", emptyPhones);


        Console.WriteLine("--- 名片 1 ---");
        Console.WriteLine(card1.GetCard());
        Console.WriteLine("\n--- 名片 2 ---");
        Console.WriteLine(card2.GetCard());
        Console.WriteLine("\n--- 名片 3 ---");
        Console.WriteLine(card3.GetCard());
    }
}