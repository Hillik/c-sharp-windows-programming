﻿// Program.cs

using System;
using System.Windows.Forms;
using WinFormsApp1;

namespace WinFormsApp1 // <-- ***重要：請確認這裡的命名空間 (Namespace) 與你的專案名稱一致***
{
    static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // 設定應用程式啟動時運行 LoginForm
            Application.Run(new LoginForm());
        }
    }
}