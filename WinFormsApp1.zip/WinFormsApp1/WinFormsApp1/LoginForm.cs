﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            // --- 這裡應該加入實際的會員驗證邏輯 ---
            // 例如：查詢資料庫，比對帳號密碼 (使用安全的雜湊比對)

            // 為了示範，我們在這裡使用一個簡單的硬編碼判斷
            if (username == "testuser" && password == "password123")
            {
                MessageBox.Show("登入成功！");

                // 隱藏當前登入表單
                this.Hide();

                // 顯示主畫面表單，並傳遞使用者名稱
                // 注意：MainForm 需要修改建構函式來接收使用者名稱
                MainForm mainForm = new MainForm(username);
                mainForm.Show();

                // 當主畫面關閉時，也關閉整個應用程式
                // 否則隱藏的登入表單會讓應用程式繼續執行
                mainForm.FormClosed += (s, args) => this.Close();
            }
            else
            {
                MessageBox.Show("帳號或密碼錯誤，請重試！");
                txtPassword.Clear(); // 清空密碼欄位
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            // 隱藏當前登入表單
            this.Hide();

            // 顯示註冊表單
            RegistrationForm registrationForm = new RegistrationForm();
            registrationForm.Show();

            // 當註冊表單關閉時，重新顯示登入表單
            registrationForm.FormClosed += (s, args) => this.Show();
        }
    }
}
