﻿namespace WinFormsApp1
{
    partial class UserProfileForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lblProfileEmail = new Label();
            txtProfileUsername = new TextBox();
            txtProfileEmail = new TextBox();
            btnSaveProfile = new Button();
            btnCancelProfile = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label1.Location = new Point(95, 58);
            label1.Name = "label1";
            label1.Size = new Size(41, 20);
            label1.TabIndex = 0;
            label1.Text = "帳號";
            // 
            // lblProfileEmail
            // 
            lblProfileEmail.AutoSize = true;
            lblProfileEmail.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblProfileEmail.Location = new Point(95, 111);
            lblProfileEmail.Name = "lblProfileEmail";
            lblProfileEmail.Size = new Size(73, 20);
            lblProfileEmail.TabIndex = 1;
            lblProfileEmail.Text = "電子郵件";
            // 
            // txtProfileUsername
            // 
            txtProfileUsername.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtProfileUsername.Location = new Point(229, 64);
            txtProfileUsername.Name = "txtProfileUsername";
            txtProfileUsername.Size = new Size(100, 28);
            txtProfileUsername.TabIndex = 2;
            // 
            // txtProfileEmail
            // 
            txtProfileEmail.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtProfileEmail.Location = new Point(229, 112);
            txtProfileEmail.Name = "txtProfileEmail";
            txtProfileEmail.Size = new Size(100, 28);
            txtProfileEmail.TabIndex = 3;
            // 
            // btnSaveProfile
            // 
            btnSaveProfile.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnSaveProfile.Location = new Point(94, 209);
            btnSaveProfile.Name = "btnSaveProfile";
            btnSaveProfile.Size = new Size(92, 30);
            btnSaveProfile.TabIndex = 4;
            btnSaveProfile.Text = "儲存變更";
            btnSaveProfile.UseVisualStyleBackColor = true;
            btnSaveProfile.Click += btnSaveProfile_Click;
            // 
            // btnCancelProfile
            // 
            btnCancelProfile.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnCancelProfile.Location = new Point(237, 209);
            btnCancelProfile.Name = "btnCancelProfile";
            btnCancelProfile.Size = new Size(92, 30);
            btnCancelProfile.TabIndex = 5;
            btnCancelProfile.Text = "取消";
            btnCancelProfile.UseVisualStyleBackColor = true;
            btnCancelProfile.Click += btnCancelProfile_Click;
            // 
            // UserProfileForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCancelProfile);
            Controls.Add(btnSaveProfile);
            Controls.Add(txtProfileEmail);
            Controls.Add(txtProfileUsername);
            Controls.Add(lblProfileEmail);
            Controls.Add(label1);
            Name = "UserProfileForm";
            Text = "UserProfileForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label lblProfileEmail;
        private TextBox txtProfileUsername;
        private TextBox txtProfileEmail;
        private Button btnSaveProfile;
        private Button btnCancelProfile;
    }
}