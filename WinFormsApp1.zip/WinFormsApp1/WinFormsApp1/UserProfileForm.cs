﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class UserProfileForm : Form
    {
        private string _loggedInUsername; // 用於存儲傳入的使用者名稱

        // 修改建構函式，接收使用者名稱
        public UserProfileForm(string username)
        {
            InitializeComponent();
            _loggedInUsername = username; // 儲存使用者名稱

            // --- 這裡應該加入根據 _loggedInUsername 從資料儲存中讀取會員詳細資料的邏輯 ---
            // 讀取資料後，顯示在對應的 TextBox 中

            // 為了示範，我們只顯示傳入的使用者名稱
            // 假設你有一個 txtProfileUsername 欄位
            // txtProfileUsername.Text = _loggedInUsername;
            // txtProfileUsername.ReadOnly = true; // 帳號通常不能修改

            // 其他欄位如電子郵件、姓名等也應在此載入並顯示
            // 例如：txtProfileEmail.Text = "user@example.com"; // 模擬載入
        }

        private void btnSaveProfile_Click(object sender, EventArgs e)
        {
            // --- 這裡應該加入收集使用者修改後的資料 ---
            // --- 以及將更新寫回資料儲存的邏輯 ---
            // 請注意：如果使用者修改了密碼，需要單獨處理並進行安全的雜湊處理！

            // 模擬儲存成功
            MessageBox.Show("會員資料已儲存。");

            // 儲存後關閉表單
            this.Close();
        }

        private void btnCancelProfile_Click(object sender, EventArgs e)
        {
            // 不保存任何變更，直接關閉表單
            this.Close();
        }
    }
}
