﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class MainForm : Form
    {
        // 新增一個私有變數來儲存使用者名稱
        private string _loggedInUsername;

        // 修改建構函式，使其接收使用者名稱
        public MainForm(string username)
        {
            InitializeComponent();
            _loggedInUsername = username; // 儲存傳入的使用者名稱

            // 在 Label 中顯示歡迎訊息
            lblWelcome.Text = $"歡迎，{_loggedInUsername}！";

            // 設定當 MainForm 關閉時觸發 LoginForm 的 FormClosed 事件
            // 這部分已經在 LoginForm 的 btnLogin_Click 中設定了
            // mainForm.FormClosed += (s, args) => this.Close();
            // 所以 MainForm 自己不需要再做額外的關閉處理，除非你想從 MainForm 裡顯式地 Application.Exit()
        }
        private void btnViewProfile_Click(object sender, EventArgs e)
        {
            // 顯示會員資料表單，使用 ShowDialog() 會阻擋 MainForm 的操作直到 UserProfileForm 關閉
            // 注意：UserProfileForm 需要修改建構函式來接收使用者名稱或完整的會員資料
            // 這裡我們只傳遞使用者名稱作為範例
            UserProfileForm profileForm = new UserProfileForm(_loggedInUsername);
            profileForm.ShowDialog(); // 以對話框模式顯示
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // 執行登出操作 (例如：清除記憶體中的使用者資訊)
            _loggedInUsername = null; // 清除使用者名稱

            // 關閉當前表單 (MainForm)
            this.Close();

            // 因為我們在 LoginForm 中設定了 mainForm.FormClosed += (s, args) => this.Close();
            // 所以關閉 MainForm 會自動關閉整個應用程式。
            // 如果你希望登出後重新回到登入畫面，需要調整 LoginForm 的邏輯
            // 例如：在 MainForm 關閉時不關閉應用程式，而是在 LoginForm 的 FormClosed 事件中判斷是否需要重新顯示自己
            // 一個簡單的回到登入頁面方法（需要修改 LoginForm 的 FormClosed 邏輯）：
            // LoginForm loginForm = new LoginForm();
            // loginForm.Show();
        }
    }
}
