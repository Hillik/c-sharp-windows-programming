﻿namespace WinFormsApp1
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtRegUsername = new TextBox();
            txtRegEmail = new TextBox();
            txtRegPassword = new TextBox();
            txtRegConfirmPassword = new TextBox();
            btnRegister = new Button();
            btnCancelReg = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label1.Location = new Point(74, 45);
            label1.Name = "label1";
            label1.Size = new Size(73, 20);
            label1.TabIndex = 0;
            label1.Text = "設定帳號";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label2.Location = new Point(74, 86);
            label2.Name = "label2";
            label2.Size = new Size(73, 20);
            label2.TabIndex = 1;
            label2.Text = "電子郵件";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label3.Location = new Point(74, 125);
            label3.Name = "label3";
            label3.Size = new Size(73, 20);
            label3.TabIndex = 2;
            label3.Text = "設定密碼";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label4.Location = new Point(74, 164);
            label4.Name = "label4";
            label4.Size = new Size(73, 20);
            label4.TabIndex = 3;
            label4.Text = "確認密碼";
            // 
            // txtRegUsername
            // 
            txtRegUsername.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtRegUsername.Location = new Point(153, 42);
            txtRegUsername.Name = "txtRegUsername";
            txtRegUsername.Size = new Size(100, 28);
            txtRegUsername.TabIndex = 4;
            // 
            // txtRegEmail
            // 
            txtRegEmail.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtRegEmail.Location = new Point(153, 83);
            txtRegEmail.Name = "txtRegEmail";
            txtRegEmail.Size = new Size(100, 28);
            txtRegEmail.TabIndex = 5;
            // 
            // txtRegPassword
            // 
            txtRegPassword.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtRegPassword.Location = new Point(153, 125);
            txtRegPassword.Name = "txtRegPassword";
            txtRegPassword.Size = new Size(100, 28);
            txtRegPassword.TabIndex = 6;
            txtRegPassword.UseSystemPasswordChar = true;
            // 
            // txtRegConfirmPassword
            // 
            txtRegConfirmPassword.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtRegConfirmPassword.Location = new Point(153, 164);
            txtRegConfirmPassword.Name = "txtRegConfirmPassword";
            txtRegConfirmPassword.Size = new Size(100, 28);
            txtRegConfirmPassword.TabIndex = 7;
            txtRegConfirmPassword.UseSystemPasswordChar = true;
            // 
            // btnRegister
            // 
            btnRegister.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnRegister.Location = new Point(72, 251);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(75, 36);
            btnRegister.TabIndex = 8;
            btnRegister.Text = "註冊";
            btnRegister.UseVisualStyleBackColor = true;
            btnRegister.Click += btnRegister_Click;
            // 
            // btnCancelReg
            // 
            btnCancelReg.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnCancelReg.Location = new Point(191, 251);
            btnCancelReg.Name = "btnCancelReg";
            btnCancelReg.Size = new Size(79, 36);
            btnCancelReg.TabIndex = 9;
            btnCancelReg.Text = "取消";
            btnCancelReg.UseVisualStyleBackColor = true;
            btnCancelReg.Click += btnCancelReg_Click;
            // 
            // RegistrationForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCancelReg);
            Controls.Add(btnRegister);
            Controls.Add(txtRegConfirmPassword);
            Controls.Add(txtRegPassword);
            Controls.Add(txtRegEmail);
            Controls.Add(txtRegUsername);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "RegistrationForm";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtRegUsername;
        private TextBox txtRegEmail;
        private TextBox txtRegPassword;
        private TextBox txtRegConfirmPassword;
        private Button btnRegister;
        private Button btnCancelReg;
    }
}