﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtRegUsername.Text;
            string email = txtRegEmail.Text;
            string password = txtRegPassword.Text;
            string confirmPassword = txtRegConfirmPassword.Text;

            // --- 這裡應該加入更嚴謹的輸入驗證 ---
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(confirmPassword))
            {
                MessageBox.Show("所有欄位都必須填寫！");
                return; // 停止後續操作
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("兩次輸入的密碼不一致！");
                txtRegPassword.Clear();
                txtRegConfirmPassword.Clear();
                return;
            }

            // --- 這裡應該加入檢查帳號/電子郵件是否已被使用 ---
            // --- 以及將新會員資料儲存到資料庫的邏輯 ---
            // 請注意：密碼在儲存前必須進行安全的雜湊處理，而不是直接存儲明文！

            // 模擬註冊成功
            MessageBox.Show("註冊成功！請返回登入頁面。");

            // 關閉當前表單，觸發 LoginForm 的 FormClosed 事件，讓登入表單重新顯示
            this.Close();
        }

        private void btnCancelReg_Click(object sender, EventArgs e)
        {
            // 直接關閉表單，觸發 LoginForm 的 FormClosed 事件，讓登入表單重新顯示
            this.Close();
        }
    }
}
