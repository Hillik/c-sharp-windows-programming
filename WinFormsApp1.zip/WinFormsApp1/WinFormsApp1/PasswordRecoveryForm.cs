﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class PasswordRecoveryForm : Form
    {
        public PasswordRecoveryForm()
        {
            InitializeComponent();
        }

        private void btnSendRecovery_Click(object sender, EventArgs e)
        {
            string email = txtRecoveryEmail.Text;

            // --- 這裡應該加入查找電子郵件並執行密碼找回流程的邏輯 ---
            // 例如：檢查電子郵件是否存在，生成重設令牌，發送郵件等。

            if (string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("請輸入您的電子郵件地址。");
                return;
            }

            // 模擬發送成功或失敗
            MessageBox.Show($"如果電子郵件 {email} 存在，密碼重設說明已發送。");

            // 操作完成後，關閉表單並返回登入畫面
            this.Close();
        }

        private void btnCancelRecovery_Click(object sender, EventArgs e)
        {
            // 直接關閉表單，返回登入畫面
            this.Close();
        }
    }
}
