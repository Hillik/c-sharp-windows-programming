﻿namespace WinFormsApp1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblWelcome = new Label();
            btnViewProfile = new Button();
            btnLogout = new Button();
            SuspendLayout();
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblWelcome.Location = new Point(342, 38);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(57, 20);
            lblWelcome.TabIndex = 0;
            lblWelcome.Text = "歡迎！";
            // 
            // btnViewProfile
            // 
            btnViewProfile.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnViewProfile.Location = new Point(106, 107);
            btnViewProfile.Name = "btnViewProfile";
            btnViewProfile.Size = new Size(91, 27);
            btnViewProfile.TabIndex = 1;
            btnViewProfile.Text = "我的資料";
            btnViewProfile.UseVisualStyleBackColor = true;
            btnViewProfile.Click += btnViewProfile_Click;
            // 
            // btnLogout
            // 
            btnLogout.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnLogout.Location = new Point(594, 107);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(79, 27);
            btnLogout.TabIndex = 2;
            btnLogout.Text = "登出";
            btnLogout.UseVisualStyleBackColor = true;
            btnLogout.Click += btnLogout_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnLogout);
            Controls.Add(btnViewProfile);
            Controls.Add(lblWelcome);
            Name = "MainForm";
            Text = "MainForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblWelcome;
        private Button btnViewProfile;
        private Button btnLogout;
    }
}