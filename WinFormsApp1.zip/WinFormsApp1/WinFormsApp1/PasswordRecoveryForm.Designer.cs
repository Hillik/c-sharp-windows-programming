﻿namespace WinFormsApp1
{
    partial class PasswordRecoveryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtRecoveryEmail = new TextBox();
            btnSendRecovery = new Button();
            btnCancelRecovery = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label1.Location = new Point(59, 56);
            label1.Name = "label1";
            label1.Size = new Size(217, 20);
            label1.TabIndex = 0;
            label1.Text = "請輸入您的註冊電子郵件地址";
            // 
            // txtRecoveryEmail
            // 
            txtRecoveryEmail.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtRecoveryEmail.Location = new Point(67, 96);
            txtRecoveryEmail.Name = "txtRecoveryEmail";
            txtRecoveryEmail.Size = new Size(209, 28);
            txtRecoveryEmail.TabIndex = 1;
            // 
            // btnSendRecovery
            // 
            btnSendRecovery.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnSendRecovery.Location = new Point(59, 161);
            btnSendRecovery.Name = "btnSendRecovery";
            btnSendRecovery.Size = new Size(188, 29);
            btnSendRecovery.TabIndex = 2;
            btnSendRecovery.Text = "傳送重設連結/驗證碼";
            btnSendRecovery.UseVisualStyleBackColor = true;
            btnSendRecovery.Click += btnSendRecovery_Click;
            // 
            // btnCancelRecovery
            // 
            btnCancelRecovery.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnCancelRecovery.Location = new Point(59, 211);
            btnCancelRecovery.Name = "btnCancelRecovery";
            btnCancelRecovery.Size = new Size(188, 29);
            btnCancelRecovery.TabIndex = 3;
            btnCancelRecovery.Text = "取消";
            btnCancelRecovery.UseVisualStyleBackColor = true;
            btnCancelRecovery.Click += btnCancelRecovery_Click;
            // 
            // PasswordRecoveryForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCancelRecovery);
            Controls.Add(btnSendRecovery);
            Controls.Add(txtRecoveryEmail);
            Controls.Add(label1);
            Name = "PasswordRecoveryForm";
            Text = "PasswordRecoveryForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtRecoveryEmail;
        private Button btnSendRecovery;
        private Button btnCancelRecovery;
    }
}