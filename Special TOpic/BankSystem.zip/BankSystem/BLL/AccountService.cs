﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using BankSystem.DAL;
using BankSystem.Models;
using System.Linq;

namespace BankSystem.BLL
{
    public class AccountService
    {
        // 定義單次存款或取款的最大金額
        private const decimal MAX_TRANSACTION_AMOUNT = 50000; // 例如，設定最大金額為 50,000 元

        public AccountService()
        {
            // 如果需要任何初始化，可以在此處添加
        }

        public Account GetAccountByUserId(int userId)
        {
            string query = "SELECT Id, UserId, AccountNumber, Balance, CreationDate FROM Accounts WHERE UserId = @UserId";
            using (SQLiteDataReader reader = DatabaseHelper.ExecuteReader(query, new SQLiteParameter("@UserId", userId)))
            {
                if (reader.Read())
                {
                    return new Account
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        UserId = Convert.ToInt32(reader["UserId"]),
                        AccountNumber = reader["AccountNumber"]?.ToString() ?? string.Empty,
                        Balance = Convert.ToDecimal(reader["Balance"]),
                        CreationDate = DateTime.Parse(reader["CreationDate"]?.ToString() ?? string.Empty)
                    };
                }
            }
            return null;
        }

        public Account GetAccountByAccountNumber(string accountNumber)
        {
            string query = "SELECT Id, UserId, AccountNumber, Balance, CreationDate FROM Accounts WHERE AccountNumber = @AccountNumber";
            using (SQLiteDataReader reader = DatabaseHelper.ExecuteReader(query, new SQLiteParameter("@AccountNumber", accountNumber)))
            {
                if (reader.Read())
                {
                    return new Account
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        UserId = Convert.ToInt32(reader["UserId"]),
                        AccountNumber = reader["AccountNumber"]?.ToString() ?? string.Empty,
                        Balance = Convert.ToDecimal(reader["Balance"]),
                        CreationDate = DateTime.Parse(reader["CreationDate"]?.ToString() ?? string.Empty)
                    };
                }
            }
            return null;
        }

        public List<Account> GetAllAccounts()
        {
            List<Account> accounts = new List<Account>();
            string query = "SELECT Id, UserId, AccountNumber, Balance, CreationDate FROM Accounts";
            using (SQLiteDataReader reader = DatabaseHelper.ExecuteReader(query))
            {
                while (reader.Read())
                {
                    accounts.Add(new Account
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        UserId = Convert.ToInt32(reader["UserId"]),
                        AccountNumber = reader["AccountNumber"].ToString(),
                        Balance = Convert.ToDecimal(reader["Balance"]),
                        CreationDate = DateTime.Parse(reader["CreationDate"]?.ToString() ?? string.Empty)
                    });
                }
            }
            return accounts;
        }

        // 創建新帳戶
        public bool CreateAccount(int userId, decimal initialBalance)
        {
            if (initialBalance < 0)
            {
                throw new ArgumentException("初始餘額不能為負數。");
            }
            if (GetAccountByUserId(userId) != null)
            {
                throw new InvalidOperationException("該用戶已擁有帳戶。");
            }

            string accountNumber = GenerateUniqueAccountNumber();
            string insertSql = @"
                INSERT INTO Accounts (UserId, AccountNumber, Balance, CreationDate)
                VALUES (@UserId, @AccountNumber, @Balance, @CreationDate);";

            SQLiteParameter[] parameters = {
                new SQLiteParameter("@UserId", userId),
                new SQLiteParameter("@AccountNumber", accountNumber),
                new SQLiteParameter("@Balance", initialBalance),
                new SQLiteParameter("@CreationDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))
            };

            int rowsAffected = DatabaseHelper.ExecuteNonQuery(insertSql, parameters);

            if (rowsAffected > 0)
            {
                return true;
            }
            return false;
        }

        // 根據 UserId 刪除所有相關帳戶
        public bool DeleteAccountsByUserId(int userId)
        {
            Account accountToDelete = GetAccountByUserId(userId);
            if (accountToDelete != null)
            {
                // 刪除帳戶前，先刪除所有相關的交易記錄
                string deleteTransactionsSql = "DELETE FROM Transactions WHERE AccountId = @AccountId";
                DatabaseHelper.ExecuteNonQuery(deleteTransactionsSql, new SQLiteParameter("@AccountId", accountToDelete.Id));
            }

            string deleteSql = "DELETE FROM Accounts WHERE UserId = @UserId";
            SQLiteParameter[] parameters = { new SQLiteParameter("@UserId", userId) };
            int rowsAffected = DatabaseHelper.ExecuteNonQuery(deleteSql, parameters);

            if (rowsAffected > 0)
            {
                return true;
            }
            return false;
        }

        // 存款
        public bool Deposit(int accountId, decimal amount, User currentUser)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("存款金額必須大於零。");
            }
            // 新增：限制單次存款最大金額
            if (amount > MAX_TRANSACTION_AMOUNT)
            {
                throw new ArgumentException($"單次存款金額不能超過 {MAX_TRANSACTION_AMOUNT:C2}。如需存入大量金額，請聯繫銀行職員協助。");
            }

            Account account = GetAccountById(accountId);
            if (account == null)
            {
                throw new ArgumentException("帳戶不存在。");
            }

            decimal newBalance = account.Balance + amount;
            string updateSql = "UPDATE Accounts SET Balance = @NewBalance WHERE Id = @AccountId";
            int rowsAffected = DatabaseHelper.ExecuteNonQuery(updateSql,
                new SQLiteParameter("@NewBalance", newBalance),
                new SQLiteParameter("@AccountId", accountId));

            if (rowsAffected > 0)
            {
                RecordTransaction(accountId, TransactionType.Deposit, amount, $"由 {currentUser.Username} 執行存款");
                return true;
            }
            return false;
        }

        // 取款
        public bool Withdraw(int accountId, decimal amount, User currentUser)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("取款金額必須大於零。");
            }
            // 新增：限制單次取款最大金額
            if (amount > MAX_TRANSACTION_AMOUNT)
            {
                throw new ArgumentException($"單次取款金額不能超過 {MAX_TRANSACTION_AMOUNT:C2}。如需提取大量金額，請聯繫銀行職員協助。");
            }

            Account account = GetAccountById(accountId);
            if (account == null)
            {
                throw new ArgumentException("帳戶不存在。");
            }

            if (account.Balance < amount)
            {
                throw new InvalidOperationException("餘額不足。");
            }

            decimal newBalance = account.Balance - amount;
            string updateSql = "UPDATE Accounts SET Balance = @NewBalance WHERE Id = @AccountId";
            int rowsAffected = DatabaseHelper.ExecuteNonQuery(updateSql,
                new SQLiteParameter("@NewBalance", newBalance),
                new SQLiteParameter("@AccountId", accountId));

            if (rowsAffected > 0)
            {
                RecordTransaction(accountId, TransactionType.Withdrawal, amount, $"由 {currentUser.Username} 執行取款");
                return true;
            }
            return false;
        }

        // 職員或行長調整客戶餘額（此方法不受 MAX_TRANSACTION_AMOUNT 限制，因為是特權操作）
        public bool AdjustCustomerBalance(int accountId, decimal amountChange, User adjuster, string description)
        {
            if (adjuster.Role < Role.Clerk)
            {
                throw new UnauthorizedAccessException("您沒有權限調整客戶餘額。");
            }

            Account account = GetAccountById(accountId);
            if (account == null)
            {
                throw new ArgumentException("帳戶不存在。");
            }

            decimal newBalance = account.Balance + amountChange;

            string updateSql = "UPDATE Accounts SET Balance = @NewBalance WHERE Id = @AccountId";
            int rowsAffected = DatabaseHelper.ExecuteNonQuery(updateSql,
                new SQLiteParameter("@NewBalance", newBalance),
                new SQLiteParameter("@AccountId", accountId));

            if (rowsAffected > 0)
            {
                RecordTransaction(accountId, TransactionType.Adjustment, amountChange, $"由 {adjuster.Username} 調整: {description}");
                return true;
            }

            return false;
        }

        public List<Transaction> GetAccountTransactions(int accountId)
        {
            List<Transaction> transactions = new List<Transaction>();
            string query = "SELECT Id, AccountId, Type, Amount, Timestamp, Description FROM Transactions WHERE AccountId = @AccountId ORDER BY Timestamp DESC";
            using (SQLiteDataReader reader = DatabaseHelper.ExecuteReader(query, new SQLiteParameter("@AccountId", accountId)))
            {
                while (reader.Read())
                {
                    transactions.Add(new Transaction
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        AccountId = Convert.ToInt32(reader["AccountId"]),
                        Type = (TransactionType)Convert.ToInt32(reader["Type"]),
                        Amount = Convert.ToDecimal(reader["Amount"]),
                        Timestamp = DateTime.Parse(reader["Timestamp"]?.ToString() ?? string.Empty),
                        Description = reader["Description"]?.ToString()
                    });
                }
            }
            return transactions;
        }

        // 獲取所有客戶餘額的總和
        public decimal GetTotalCustomerBalances()
        {
            string query = "SELECT SUM(Balance) FROM Accounts";
            object result = DatabaseHelper.ExecuteScalar(query);
            return result == DBNull.Value ? 0 : Convert.ToDecimal(result);
        }

        // 獲取銀行營運資金
        public decimal GetBankOperationalFunds()
        {
            string query = "SELECT Funds FROM BankOperationalFunds WHERE Id = 1";
            object result = DatabaseHelper.ExecuteScalar(query);
            return result == DBNull.Value ? 0 : Convert.ToDecimal(result);
        }

        // 修改銀行營運資金 (內部方法，用於銀行自身行為，而不是客戶行為)
        private void UpdateBankOperationalFunds(decimal amount)
        {
            decimal currentFunds = GetBankOperationalFunds();
            decimal newFunds = currentFunds + amount;

            string updateSql = @"
                INSERT OR REPLACE INTO BankOperationalFunds (Id, Funds)
                VALUES (1, @Funds);";

            DatabaseHelper.ExecuteNonQuery(updateSql, new SQLiteParameter("@Funds", newFunds));
        }

        // 調整銀行營運資金 (手動調整，需要行長和副行長雙重驗證)
        public bool AdjustBankOperationalFunds(decimal newFunds, User president, User vicePresidentAuth = null, string operationDescription = null)
        {
            if (president.Role != Role.President)
            {
                throw new UnauthorizedAccessException("只有行長有權限修改銀行營運資金。");
            }
            if (vicePresidentAuth == null || vicePresidentAuth.Role != Role.VicePresident)
            {
                throw new UnauthorizedAccessException("修改營運資金需要一位副行長的雙重驗證。");
            }
            if (string.IsNullOrWhiteSpace(operationDescription))
            {
                throw new ArgumentException("修改營運資金必須提供操作說明。");
            }

            string updateSql = @"
                INSERT OR REPLACE INTO BankOperationalFunds (Id, Funds)
                VALUES (1, @Funds);";

            int rowsAffected = DatabaseHelper.ExecuteNonQuery(updateSql, new SQLiteParameter("@Funds", newFunds));

            if (rowsAffected > 0)
            {
                return true;
            }
            return false;
        }

        private Account GetAccountById(int accountId)
        {
            string query = "SELECT Id, UserId, AccountNumber, Balance, CreationDate FROM Accounts WHERE Id = @Id";
            using (SQLiteDataReader reader = DatabaseHelper.ExecuteReader(query, new SQLiteParameter("@Id", accountId)))
            {
                if (reader.Read())
                {
                    return new Account
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        UserId = Convert.ToInt32(reader["UserId"]),
                        AccountNumber = reader["AccountNumber"]?.ToString() ?? string.Empty,
                        Balance = Convert.ToDecimal(reader["Balance"]),
                        CreationDate = DateTime.Parse(reader["CreationDate"].ToString())
                    };
                }
            }
            return null;
        }

        // 產生唯一的帳號
        private string GenerateUniqueAccountNumber()
        {
            string newAccountNumber;
            do
            {
                newAccountNumber = "ACC" + DateTime.Now.ToString("yyyyMMddHHmmss") + new Random().Next(100, 999).ToString();
            } while (GetAccountByAccountNumber(newAccountNumber) != null);

            return newAccountNumber;
        }

        // 記錄交易的輔助方法
        private void RecordTransaction(int accountId, TransactionType type, decimal amount, string description)
        {
            string insertSql = @"
                INSERT INTO Transactions (AccountId, Type, Amount, Timestamp, Description)
                VALUES (@AccountId, @Type, @Amount, @Timestamp, @Description);";
            SQLiteParameter[] parameters = {
                new SQLiteParameter("@AccountId", accountId),
                new SQLiteParameter("@Type", (int)type),
                new SQLiteParameter("@Amount", amount),
                new SQLiteParameter("@Timestamp", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")),
                new SQLiteParameter("@Description", description)
            };
            DatabaseHelper.ExecuteNonQuery(insertSql, parameters);
        }
    }
}