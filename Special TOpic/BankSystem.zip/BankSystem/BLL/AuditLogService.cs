﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using BankSystem.DAL;
using BankSystem.Models;

namespace BankSystem.BLL
{
    public class AuditLogService
    {
        public List<AuditLog> GetAllAuditLogs()
        {
            List<AuditLog> logs = new List<AuditLog>();
            string query = "SELECT Id, Type, PerformedByUsername, Timestamp, Description, RelatedInfo FROM AuditLog ORDER BY Timestamp DESC";
            using (SQLiteDataReader reader = DatabaseHelper.ExecuteReader(query))
            {
                while (reader.Read())
                {
                    logs.Add(new AuditLog
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Type = (AuditLogType)Convert.ToInt32(reader["Type"]),
                        PerformedByUsername = reader["PerformedByUsername"].ToString(),
                        Timestamp = DateTime.Parse(reader["Timestamp"]?.ToString() ?? string.Empty),
                        Description = reader["Description"].ToString(),
                        RelatedInfo = reader["RelatedInfo"]?.ToString()
                    });
                }
            }
            return logs;
        }

        // 可以添加更多查詢方法，例如按類型、按用戶、按日期範圍等
    }
}