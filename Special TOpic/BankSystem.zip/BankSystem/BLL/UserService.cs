﻿using System;
using System.Collections.Generic;
using System.Data.SQLite; // 確保有引用 SQLite
using BankSystem.DAL;
using BankSystem.Models;

namespace BankSystem.BLL
{
    public class UserService
    {
        // 新增 AccountService 的實例
        private AccountService _accountService;

        public UserService()
        {
            // 在建構函式中初始化 AccountService
            _accountService = new AccountService();
        }

        public User AuthenticateUser(string username, string password)
        {
            string query = "SELECT Id, Username, PasswordHash, Name, Role, CreationDate FROM Users WHERE Username = @Username";
            SQLiteParameter[] parameters = {
                new SQLiteParameter("@Username", username)
            };

            using (SQLiteDataReader reader = DatabaseHelper.ExecuteReader(query, parameters))
            {
                if (reader.Read())
                {
                    string storedPasswordHash = reader["PasswordHash"].ToString();
                    if (DatabaseHelper.VerifyPassword(password, storedPasswordHash))
                    {
                        return new User
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Username = reader["Username"].ToString(),
                            PasswordHash = storedPasswordHash,
                            Name = reader["Name"].ToString(),
                            Role = (Role)Convert.ToInt32(reader["Role"]),
                            CreationDate = DateTime.Parse(reader["CreationDate"]?.ToString() ?? string.Empty)
                        };
                    }
                }
            }
            return null; // 認證失敗
        }

        public bool CreateUser(string username, string password, string name, Role role, User creator)
        {
            // 檢查權限：只有職員及以上才能創建用戶
            // 職員可創建客戶
            // 副行長可創建客戶、職員
            // 行長可創建所有角色
            if (creator.Role < Role.Clerk ||
                (creator.Role == Role.Clerk && role > Role.Customer) ||
                (creator.Role == Role.VicePresident && role > Role.Clerk))
            {
                throw new UnauthorizedAccessException("您沒有足夠的權限創建此類型的用戶。");
            }

            // 檢查用戶名是否已存在
            string checkUserSql = "SELECT COUNT(*) FROM Users WHERE Username = @Username";
            int userCount = Convert.ToInt32(DatabaseHelper.ExecuteScalar(checkUserSql, new SQLiteParameter("@Username", username)));
            if (userCount > 0)
            {
                throw new InvalidOperationException("使用者名稱已存在，請選擇其他名稱。");
            }

            string hashedPassword = DatabaseHelper.HashPassword(password);
            string insertSql = @"
                INSERT INTO Users (Username, PasswordHash, Name, Role, CreationDate)
                VALUES (@Username, @PasswordHash, @Name, @Role, @CreationDate);";

            SQLiteParameter[] parameters = {
                new SQLiteParameter("@Username", username),
                new SQLiteParameter("@PasswordHash", hashedPassword),
                new SQLiteParameter("@Name", name),
                new SQLiteParameter("@Role", (int)role),
                new SQLiteParameter("@CreationDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))
            };

            int rowsAffected = DatabaseHelper.ExecuteNonQuery(insertSql, parameters);

            if (rowsAffected > 0)
            {
                // 如果是客戶，創建一個新的帳戶
                if (role == Role.Customer)
                {
                    // 獲取新創建用戶的ID
                    string getUserIdSql = "SELECT Id FROM Users WHERE Username = @Username";
                    int newUserId = Convert.ToInt32(DatabaseHelper.ExecuteScalar(getUserIdSql, new SQLiteParameter("@Username", username)));

                    // _accountService 已在建構函式中初始化
                    _accountService.CreateAccount(newUserId, 0); // 為新客戶創建一個初始餘額為0的帳戶
                }

                // 記錄審計日誌
                LogAudit(AuditLogType.UserCreation, creator.Username, $"創建了新用戶: {username} (角色: {role})", username);
                return true;
            }
            return false;
        }

        public bool DeleteUser(int userId, User deleter)
        {
            User userToDelete = GetUserById(userId);
            if (userToDelete == null)
            {
                throw new ArgumentException("要刪除的用戶不存在。");
            }

            // 權限檢查：
            // 職員不能刪除用戶
            // 副行長不能刪除比自己權限高的用戶 (行長)
            // 行長可以刪除所有用戶

            // 不能刪除自己
            if (deleter.Id == userId)
            {
                throw new InvalidOperationException("您不能刪除您自己的帳號。");
            }

            // 綜合權限判斷：
            // 1. 刪除者角色必須高於或等於被刪除者角色 (只有行長可以刪除行長，但我們已禁止自刪)
            // 2. 職員沒有刪除權限 (因為上面沒有明確列出職員可刪除誰，所以假設職員不能刪除任何用戶)
            if (deleter.Role < Role.VicePresident || // 職員及以下無刪除權限 (假設只有副行長及以上有刪除權限)
                deleter.Role < userToDelete.Role) // 刪除者權限必須高於被刪除者
            {
                throw new UnauthorizedAccessException("您沒有足夠的權限刪除此用戶。");
            }

            // 特殊情況：副行長不能刪除行長
            if (deleter.Role == Role.VicePresident && userToDelete.Role == Role.President)
            {
                throw new UnauthorizedAccessException("副行長不能刪除行長帳戶。");
            }


            try
            {
                // 1. 刪除與該用戶相關的所有帳戶
                // 假設 Accounts 表中的 UserId 欄位是用戶的外鍵
                // 您需要確保 AccountService.DeleteAccountsByUserId 方法存在並正確執行刪除操作
                _accountService.DeleteAccountsByUserId(userId);

                // 2. 刪除用戶本身
                string deleteUserSql = "DELETE FROM Users WHERE Id = @Id";
                int rowsAffected = DatabaseHelper.ExecuteNonQuery(deleteUserSql, new SQLiteParameter("@Id", userId));

                if (rowsAffected > 0)
                {
                    // 記錄審計日誌
                    LogAudit(AuditLogType.UserDeletion, deleter.Username, $"刪除了用戶: {userToDelete.Username} (角色: {userToDelete.Role})", userToDelete.Username);
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                // 這裡可以根據需要進行更詳細的錯誤處理和日誌記錄
                // 例如：Log.Error("刪除用戶及資產失敗", ex);
                throw new ApplicationException($"刪除用戶及其資產失敗: {ex.Message}", ex);
            }
        }

        public bool UpdateUserRole(int userId, Role newRole, User updater)
        {
            User userToUpdate = GetUserById(userId);
            if (userToUpdate == null)
            {
                throw new ArgumentException("要更新角色的用戶不存在。");
            }

            // 權限檢查：
            // 職員不能修改角色
            // 副行長不能將任何用戶角色設置為行長，也不能修改行長角色
            // 行長可以修改所有角色，但不能將自己降級
            if (updater.Role < Role.VicePresident || // 職員不能修改角色
                (updater.Role == Role.VicePresident && (newRole == Role.President || userToUpdate.Role == Role.President)) || // 副行長不能碰行長
                (updater.Id == userId && newRole < updater.Role)) // 不能將自己降級
            {
                throw new UnauthorizedAccessException("您沒有足夠的權限修改此用戶的角色。");
            }

            string updateSql = "UPDATE Users SET Role = @Role WHERE Id = @Id";
            int rowsAffected = DatabaseHelper.ExecuteNonQuery(updateSql,
                new SQLiteParameter("@Role", (int)newRole),
                new SQLiteParameter("@Id", userId));

            if (rowsAffected > 0)
            {
                // 記錄審計日誌
                LogAudit(AuditLogType.UserRoleChange, updater.Username, $"修改了用戶 {userToUpdate.Username} 的角色從 {userToUpdate.Role} 到 {newRole}", userToUpdate.Username);
                return true;
            }
            return false;
        }

        public User GetUserById(int userId)
        {
            string query = "SELECT Id, Username, PasswordHash, Name, Role, CreationDate FROM Users WHERE Id = @Id";
            using (SQLiteDataReader reader = DatabaseHelper.ExecuteReader(query, new SQLiteParameter("@Id", userId)))
            {
                if (reader.Read())
                {
                    return new User
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Username = reader["Username"]?.ToString() ?? string.Empty,
                        PasswordHash = reader["PasswordHash"].ToString(),
                        Name = reader["Name"].ToString(),
                        Role = (Role)Convert.ToInt32(reader["Role"]),
                        CreationDate = DateTime.Parse(reader["CreationDate"]?.ToString() ?? string.Empty)
                    };
                }
            }
            return null;
        }

        public User GetUserByUsername(string username)
        {
            string query = "SELECT Id, Username, PasswordHash, Name, Role, CreationDate FROM Users WHERE Username = @Username";
            using (SQLiteDataReader reader = DatabaseHelper.ExecuteReader(query, new SQLiteParameter("@Username", username)))
            {
                if (reader.Read())
                {
                    return new User
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Username = reader["Username"].ToString(),
                        PasswordHash = reader["PasswordHash"].ToString(),
                        Name = reader["Name"].ToString(),
                        Role = (Role)Convert.ToInt32(reader["Role"]),
                        CreationDate = DateTime.Parse(reader["CreationDate"].ToString())
                    };
                }
            }
            return null;
        }

        public List<User> GetAllUsers()
        {
            List<User> users = new List<User>();
            string query = "SELECT Id, Username, PasswordHash, Name, Role, CreationDate FROM Users";
            using (SQLiteDataReader reader = DatabaseHelper.ExecuteReader(query))
            {
                while (reader.Read())
                {
                    users.Add(new User
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Username = reader["Username"].ToString(),
                        PasswordHash = reader["PasswordHash"].ToString(),
                        Name = reader["Name"].ToString(),
                        Role = (Role)Convert.ToInt32(reader["Role"]),
                        CreationDate = DateTime.Parse(reader["CreationDate"].ToString())
                    });
                }
            }
            return users;
        }


        // 內部方法，用於記錄審計日誌
        public void LogAudit(AuditLogType type, string performedBy, string description, string relatedInfo = null)
        {
            string insertSql = @"
                INSERT INTO AuditLog (Type, PerformedByUsername, Timestamp, Description, RelatedInfo)
                VALUES (@Type, @PerformedByUsername, @Timestamp, @Description, @RelatedInfo);";
            SQLiteParameter[] parameters = {
                new SQLiteParameter("@Type", (int)type),
                new SQLiteParameter("@PerformedByUsername", performedBy),
                new SQLiteParameter("@Timestamp", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")),
                new SQLiteParameter("@Description", description),
                new SQLiteParameter("@RelatedInfo", relatedInfo)
            };
            DatabaseHelper.ExecuteNonQuery(insertSql, parameters);
        }
        // 公共方法供其他服務調用
        public void RecordAuditLog(AuditLogType type, string performedByUsername, string description, string relatedInfo = null)
        {
            LogAudit(type, performedByUsername, description, relatedInfo);
        }
    }
}