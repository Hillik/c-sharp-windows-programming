﻿using System;
using System.Data.SQLite;
using System.IO;
using System.Security.Cryptography; // 用於密碼雜湊
using System.Text;
using BankSystem.Models;

namespace BankSystem.DAL
{
    public class DatabaseHelper
    {
        private static string DbFilePath = "BankSystem.db"; // 資料庫檔案名稱
        private static string ConnectionString = $"Data Source={DbFilePath};Version=3;";

        public static void InitializeDatabase()
        {
            if (!File.Exists(DbFilePath))
            {
                SQLiteConnection.CreateFile(DbFilePath);
                Console.WriteLine("Database file created.");
            }

            using (var connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();
                CreateTables(connection);
                CreateInitialData(connection);
            }
        }

        private static void CreateTables(SQLiteConnection connection)
        {
            // Users Table
            string createUsersTableSql = @"
                CREATE TABLE IF NOT EXISTS Users (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Username TEXT NOT NULL UNIQUE,
                    PasswordHash TEXT NOT NULL,
                    Name TEXT NOT NULL,
                    Role INTEGER NOT NULL, -- 0=Customer, 1=Clerk, 2=VicePresident, 3=President
                    CreationDate TEXT NOT NULL
                );";
            using (var command = new SQLiteCommand(createUsersTableSql, connection))
            {
                command.ExecuteNonQuery();
            }

            // Accounts Table
            string createAccountsTableSql = @"
                CREATE TABLE IF NOT EXISTS Accounts (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    UserId INTEGER NOT NULL,
                    AccountNumber TEXT NOT NULL UNIQUE,
                    Balance REAL NOT NULL, -- REAL for decimal values in SQLite
                    CreationDate TEXT NOT NULL,
                    FOREIGN KEY(UserId) REFERENCES Users(Id) ON DELETE CASCADE
                );";
            using (var command = new SQLiteCommand(createAccountsTableSql, connection))
            {
                command.ExecuteNonQuery();
            }

            // Transactions Table
            string createTransactionsTableSql = @"
                CREATE TABLE IF NOT EXISTS Transactions (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    AccountId INTEGER NOT NULL,
                    Type INTEGER NOT NULL, -- 0=Deposit, 1=Withdrawal, 2=Adjustment
                    Amount REAL NOT NULL,
                    Timestamp TEXT NOT NULL,
                    Description TEXT,
                    FOREIGN KEY(AccountId) REFERENCES Accounts(Id) ON DELETE CASCADE
                );";
            using (var command = new SQLiteCommand(createTransactionsTableSql, connection))
            {
                command.ExecuteNonQuery();
            }

            // BankOperationalFunds Table (只儲存一筆數據)
            string createBankOperationalFundsTableSql = @"
                CREATE TABLE IF NOT EXISTS BankOperationalFunds (
                    Id INTEGER PRIMARY KEY DEFAULT 1, -- 固定ID為1
                    Funds REAL NOT NULL
                );";
            using (var command = new SQLiteCommand(createBankOperationalFundsTableSql, connection))
            {
                command.ExecuteNonQuery();
            }

            // AuditLog Table
            string createAuditLogTableSql = @"
                CREATE TABLE IF NOT EXISTS AuditLog (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Type INTEGER NOT NULL, -- 0=UserCreation, 1=UserDeletion, 2=UserRoleChange, 3=CustomerBalanceAdjustment, 4=OperationalFundsAdjustment
                    PerformedByUsername TEXT NOT NULL,
                    Timestamp TEXT NOT NULL,
                    Description TEXT NOT NULL,
                    RelatedInfo TEXT
                );";
            using (var command = new SQLiteCommand(createAuditLogTableSql, connection))
            {
                command.ExecuteNonQuery();
            }

            Console.WriteLine("Tables checked/created.");
        }

        private static void CreateInitialData(SQLiteConnection connection)
        {
            // 檢查是否已有行長帳號，若無則創建
            string checkPresidentSql = "SELECT COUNT(*) FROM Users WHERE Role = @Role";
            using (var command = new SQLiteCommand(checkPresidentSql, connection))
            {
                command.Parameters.AddWithValue("@Role", (int)Role.President);
                if (Convert.ToInt32(command.ExecuteScalar()) == 0)
                {
                    Console.WriteLine("Creating initial President account...");
                    string username = "admin";
                    string password = "password"; // 初始密碼
                    string hashedPassword = HashPassword(password);

                    string insertPresidentSql = @"
                        INSERT INTO Users (Username, PasswordHash, Name, Role, CreationDate)
                        VALUES (@Username, @PasswordHash, @Name, @Role, @CreationDate);";
                    using (var insertCommand = new SQLiteCommand(insertPresidentSql, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@Username", username);
                        insertCommand.Parameters.AddWithValue("@PasswordHash", hashedPassword);
                        insertCommand.Parameters.AddWithValue("@Name", "銀行行長");
                        insertCommand.Parameters.AddWithValue("@Role", (int)Role.President);
                        insertCommand.Parameters.AddWithValue("@CreationDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                        insertCommand.ExecuteNonQuery();
                    }
                    Console.WriteLine($"President account '{username}' created with password '{password}'.");
                }
            }

            // 檢查是否已有 BankOperationalFunds，若無則插入初始值
            string checkFundsSql = "SELECT COUNT(*) FROM BankOperationalFunds WHERE Id = 1";
            using (var command = new SQLiteCommand(checkFundsSql, connection))
            {
                if (Convert.ToInt32(command.ExecuteScalar()) == 0)
                {
                    Console.WriteLine("Setting initial Bank Operational Funds...");
                    string insertFundsSql = "INSERT INTO BankOperationalFunds (Id, Funds) VALUES (1, 1000000.00);"; // 初始營運資金 100 萬
                    using (var insertCommand = new SQLiteCommand(insertFundsSql, connection))
                    {
                        insertCommand.ExecuteNonQuery();
                    }
                    Console.WriteLine("Initial Bank Operational Funds set to 1,000,000.00.");
                }
            }
        }

        // --- 密碼雜湊和驗證方法 ---
        public static string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        public static bool VerifyPassword(string password, string hashedPassword)
        {
            return HashPassword(password) == hashedPassword;
        }

        // --- 通用查詢方法 ---
        public static SQLiteDataReader ExecuteReader(string query, params SQLiteParameter[] parameters)
        {
            SQLiteConnection connection = new SQLiteConnection(ConnectionString); // 每次創建新的連接，由呼叫者關閉
            connection.Open();
            SQLiteCommand command = new SQLiteCommand(query, connection);
            command.Parameters.AddRange(parameters);
            return command.ExecuteReader(System.Data.CommandBehavior.CloseConnection); // 執行完畢後關閉連接
        }

        public static int ExecuteNonQuery(string query, params SQLiteParameter[] parameters)
        {
            using (var connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddRange(parameters);
                    return command.ExecuteNonQuery();
                }
            }
        }

        public static object ExecuteScalar(string query, params SQLiteParameter[] parameters)
        {
            using (var connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddRange(parameters);
                    return command.ExecuteScalar();
                }
            }
        }
    }
}