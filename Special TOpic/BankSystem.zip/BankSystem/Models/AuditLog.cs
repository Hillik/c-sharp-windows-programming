﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankSystem.Models
{
    public enum AuditLogType
    {
        UserCreation,
        UserDeletion,
        UserRoleChange,
        CustomerBalanceAdjustment,
        OperationalFundsAdjustment
    }

    public class AuditLog
    {
        public int Id { get; set; }
        public AuditLogType Type { get; set; }
        public string PerformedByUsername { get; set; } // 執行操作的使用者名稱
        public DateTime Timestamp { get; set; }
        public string Description { get; set; } // 操作的詳細描述
        public string RelatedInfo { get; set; } // 相關的ID或名稱 (例如: 被操作的用戶名/帳號)
    }
}