﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankSystem.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string PasswordHash { get; set; } // 儲存密碼的雜湊值
        public string Name { get; set; }
        public Role Role { get; set; }
        public DateTime CreationDate { get; set; }
    }
}
