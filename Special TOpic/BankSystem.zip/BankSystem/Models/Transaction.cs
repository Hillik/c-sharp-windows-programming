﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankSystem.Models
{
    public enum TransactionType
    {
        Deposit,    // 存款
        Withdrawal, // 取款
        Adjustment  // 餘額調整 (職員/行長操作)
    }

    public class Transaction
    {
        public int Id { get; set; }
        public int AccountId { get; set; } // 關聯到 Account.Id
        public TransactionType Type { get; set; }
        public decimal Amount { get; set; }
        public DateTime Timestamp { get; set; }
        public string Description { get; set; } // 交易描述 (例如: 職員調整餘額原因)
    }
}
