﻿using System;
using System.Windows.Forms;
using BankSystem.BLL; // 我們稍後會建立這個業務邏輯層
using BankSystem.Models;

namespace BankSystem
{
    public partial class LoginForm : Form
    {
        private UserService _userService; // 業務邏輯層的服務

        public LoginForm()
        {
            InitializeComponent();
            _userService = new UserService(); // 初始化服務
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            User loggedInUser = _userService.AuthenticateUser(username, password);

            if (loggedInUser != null)
            {
                MessageBox.Show($"登入成功！歡迎您，{loggedInUser.Name} ({loggedInUser.Role})。", "登入成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // 根據角色導向不同介面
                // 為了簡化，目前先示範關閉登入視窗
                // 後續會根據角色打開不同的主表單
                this.Hide(); // 隱藏登入視窗

                // 這裡會是根據不同角色開啟不同表單的邏輯
                // 為了現在，我們簡單地開啟一個顯示登入成功的表單 (例如一個空的主表單，之後會改寫)
                MainForm mainForm = new MainForm(loggedInUser); // 假設有一個 MainForm 接收登入用戶
                mainForm.Closed += (s, args) => this.Close(); // 當主表單關閉時，關閉登入表單
                mainForm.Show();
            }
            else
            {
                MessageBox.Show("登入失敗：使用者名稱或密碼錯誤。", "登入失敗", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}