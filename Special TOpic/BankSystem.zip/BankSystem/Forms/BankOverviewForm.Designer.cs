﻿namespace BankSystem.Forms
{
    partial class BankOverviewForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblOperationalFundsTitle = new System.Windows.Forms.Label();
            this.lblOperationalFunds = new System.Windows.Forms.Label();
            this.lblTotalBankAssetsTitle = new System.Windows.Forms.Label();
            this.lblTotalBankAssets = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridViewAccounts = new System.Windows.Forms.DataGridView();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnAdjustBalance = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAccounts)).BeginInit();
            this.SuspendLayout();
            //
            // lblTitle
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblTitle.Location = new System.Drawing.Point(20, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(96, 26);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "銀行總覽";
            //
            // lblOperationalFundsTitle
            //
            this.lblOperationalFundsTitle.AutoSize = true;
            this.lblOperationalFundsTitle.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblOperationalFundsTitle.Location = new System.Drawing.Point(21, 60);
            this.lblOperationalFundsTitle.Name = "lblOperationalFundsTitle";
            this.lblOperationalFundsTitle.Size = new System.Drawing.Size(0, 19);
            this.lblOperationalFundsTitle.TabIndex = 1;
            this.lblOperationalFundsTitle.Text = "銀行營運資金:";
            this.lblOperationalFundsTitle.Visible = false;
            //
            // lblOperationalFunds
            //
            this.lblOperationalFunds.AutoSize = true;
            this.lblOperationalFunds.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblOperationalFunds.Location = new System.Drawing.Point(140, 60);
            this.lblOperationalFunds.Name = "lblOperationalFunds";
            this.lblOperationalFunds.Size = new System.Drawing.Size(0, 19);
            this.lblOperationalFunds.TabIndex = 2;
            this.lblOperationalFunds.Text = "N/A";
            this.lblOperationalFunds.Visible = false;
            //
            // lblTotalBankAssetsTitle
            //
            this.lblTotalBankAssetsTitle.AutoSize = true;
            this.lblTotalBankAssetsTitle.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblTotalBankAssetsTitle.Location = new System.Drawing.Point(21, 90);
            this.lblTotalBankAssetsTitle.Name = "lblTotalBankAssetsTitle";
            this.lblTotalBankAssetsTitle.Size = new System.Drawing.Size(0, 20);
            this.lblTotalBankAssetsTitle.TabIndex = 3;
            this.lblTotalBankAssetsTitle.Text = "銀行總資產:";
            this.lblTotalBankAssetsTitle.Visible = false;
            //
            // lblTotalBankAssets
            //
            this.lblTotalBankAssets.AutoSize = true;
            this.lblTotalBankAssets.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblTotalBankAssets.Location = new System.Drawing.Point(140, 90);
            this.lblTotalBankAssets.Name = "lblTotalBankAssets";
            this.lblTotalBankAssets.Size = new System.Drawing.Size(0, 20);
            this.lblTotalBankAssets.TabIndex = 4;
            this.lblTotalBankAssets.Text = "N/A";
            this.lblTotalBankAssets.Visible = false;
            //
            // label6
            //
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(20, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 26);
            this.label6.TabIndex = 5;
            this.label6.Text = "所有客戶餘額";
            //
            // dataGridViewAccounts
            //
            this.dataGridViewAccounts.AllowUserToAddRows = false;
            this.dataGridViewAccounts.AllowUserToDeleteRows = false;
            this.dataGridViewAccounts.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewAccounts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAccounts.Location = new System.Drawing.Point(25, 180);
            this.dataGridViewAccounts.MultiSelect = false;
            this.dataGridViewAccounts.Name = "dataGridViewAccounts";
            this.dataGridViewAccounts.ReadOnly = true;
            this.dataGridViewAccounts.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridViewAccounts.RowTemplate.Height = 24;
            this.dataGridViewAccounts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewAccounts.Size = new System.Drawing.Size(550, 210);
            this.dataGridViewAccounts.TabIndex = 6;
            //
            // btnRefresh
            //
            this.btnRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnRefresh.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnRefresh.Location = new System.Drawing.Point(25, 405);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(100, 30);
            this.btnRefresh.TabIndex = 7;
            this.btnRefresh.Text = "刷新數據";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            //
            // btnAdjustBalance
            //
            this.btnAdjustBalance.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAdjustBalance.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnAdjustBalance.Location = new System.Drawing.Point(475, 405);
            this.btnAdjustBalance.Name = "btnAdjustBalance";
            this.btnAdjustBalance.Size = new System.Drawing.Size(100, 30);
            this.btnAdjustBalance.TabIndex = 8;
            this.btnAdjustBalance.Text = "調整客戶餘額";
            this.btnAdjustBalance.UseVisualStyleBackColor = true;
            this.btnAdjustBalance.Click += new System.EventHandler(this.btnAdjustBalance_Click);
            //
            // BankOverviewForm
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 450);
            this.Controls.Add(this.btnAdjustBalance);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dataGridViewAccounts);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblTotalBankAssets);
            this.Controls.Add(this.lblTotalBankAssetsTitle);
            this.Controls.Add(this.lblOperationalFunds);
            this.Controls.Add(this.lblOperationalFundsTitle);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BankOverviewForm";
            this.Text = "BankOverviewForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAccounts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblOperationalFundsTitle;
        private System.Windows.Forms.Label lblOperationalFunds;
        private System.Windows.Forms.Label lblTotalBankAssetsTitle;
        private System.Windows.Forms.Label lblTotalBankAssets;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridViewAccounts;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnAdjustBalance;
    }
}