﻿using System;
using System.Windows.Forms;
using BankSystem.BLL;
using BankSystem.Models;
using System.Collections.Generic;

namespace BankSystem.Forms
{
    public partial class AuditLogForm : Form
    {
        private User _loggedInUser;
        private AuditLogService _auditLogService;

        public AuditLogForm(User user)
        {
            InitializeComponent();
            _loggedInUser = user;
            _auditLogService = new AuditLogService();

            if (_loggedInUser.Role != Role.President)
            {
                MessageBox.Show("您沒有權限查看審計日誌。", "權限不足", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Controls.Clear();
                return;
            }

            LoadAuditLogs();
        }

        private void LoadAuditLogs()
        {
            List<AuditLog> logs = _auditLogService.GetAllAuditLogs();
            dataGridViewAuditLog.DataSource = logs;

            // 調整 DataGridView 顯示
            dataGridViewAuditLog.Columns["Id"].Visible = false;
            dataGridViewAuditLog.Columns["Type"].HeaderText = "日誌類型";
            dataGridViewAuditLog.Columns["PerformedByUsername"].HeaderText = "操作者";
            dataGridViewAuditLog.Columns["Timestamp"].HeaderText = "時間";
            dataGridViewAuditLog.Columns["Description"].HeaderText = "描述";
            dataGridViewAuditLog.Columns["RelatedInfo"].HeaderText = "相關資訊";
            dataGridViewAuditLog.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadAuditLogs();
        }
    }
}