﻿using System;
using System.Windows.Forms;
using BankSystem.BLL;
using BankSystem.Models;
using System.Drawing; // 可能需要此引用，用於調整 DataGridView 的視覺效果

namespace BankSystem.Forms
{
    public partial class CustomerAccountForm : Form
    {
        private User _loggedInUser;
        private AccountService _accountService;
        private Account _customerAccount;

        public CustomerAccountForm(User user)
        {
            InitializeComponent();
            _loggedInUser = user;
            _accountService = new AccountService(); // 實例化 AccountService

            // 根據用戶角色限制功能
            if (_loggedInUser.Role != Role.Customer)
            {
                // 如果不是客戶，則不能使用此表單的交易功能
                MessageBox.Show("您沒有客戶帳戶權限，無法使用此功能。", "權限不足", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                btnDeposit.Enabled = false;
                btnWithdraw.Enabled = false;
                txtAmount.Enabled = false;
                // 可能還需要隱藏或禁用其他客戶專用的UI元素
            }

            LoadAccountInfo(); // 初始化時載入帳戶資訊和交易
        }

        private void LoadAccountInfo()
        {
            // 根據登入用戶的ID獲取其帳戶信息
            _customerAccount = _accountService.GetAccountByUserId(_loggedInUser.Id);

            if (_customerAccount != null)
            {
                // 顯示帳號和餘額
                lblAccountNumber.Text = $"帳號: {_customerAccount.AccountNumber}";
                lblBalance.Text = $"餘額: {_customerAccount.Balance:C2}"; // 使用貨幣格式顯示餘額

                LoadTransactions(); // 載入交易記錄
            }
            else
            {
                // 如果用戶沒有帳戶，則顯示相應提示並禁用交易功能
                lblAccountNumber.Text = "帳號: 無";
                lblBalance.Text = "餘額: N/A";
                MessageBox.Show("您尚未擁有客戶帳戶，請聯繫銀行職員創建。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnDeposit.Enabled = false;
                btnWithdraw.Enabled = false;
                txtAmount.Enabled = false;
            }
        }

        private void LoadTransactions()
        {
            if (_customerAccount != null)
            {
                // 獲取並綁定交易記錄到 DataGridView
                var transactions = _accountService.GetAccountTransactions(_customerAccount.Id);
                dataGridViewTransactions.DataSource = transactions;

                // 調整 DataGridView 列的顯示標題和可見性
                if (dataGridViewTransactions.Columns.Contains("Id"))
                    dataGridViewTransactions.Columns["Id"].Visible = false;
                if (dataGridViewTransactions.Columns.Contains("AccountId"))
                    dataGridViewTransactions.Columns["AccountId"].Visible = false;
                if (dataGridViewTransactions.Columns.Contains("Type"))
                    dataGridViewTransactions.Columns["Type"].HeaderText = "類型";
                if (dataGridViewTransactions.Columns.Contains("Amount"))
                    dataGridViewTransactions.Columns["Amount"].HeaderText = "金額";
                if (dataGridViewTransactions.Columns.Contains("Timestamp"))
                    dataGridViewTransactions.Columns["Timestamp"].HeaderText = "時間";
                if (dataGridViewTransactions.Columns.Contains("Description"))
                    dataGridViewTransactions.Columns["Description"].HeaderText = "描述";

                // 自動調整列寬以適應內容
                dataGridViewTransactions.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }
            else
            {
                dataGridViewTransactions.DataSource = null; // 如果沒有帳戶，清空 DataGridView
            }
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            // 如果沒有客戶帳戶，則直接返回
            if (_customerAccount == null) return;

            // 嘗試解析輸入的金額
            if (decimal.TryParse(txtAmount.Text, out decimal amount) && amount > 0)
            {
                try
                {
                    // 呼叫 AccountService 的存款方法
                    if (_accountService.Deposit(_customerAccount.Id, amount, _loggedInUser))
                    {
                        MessageBox.Show("存款成功！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadAccountInfo(); // 存款成功後重新載入帳戶資訊和交易記錄
                        txtAmount.Clear(); // 清空輸入框
                    }
                }
                catch (ArgumentException ex) // 捕獲特定類型的錯誤（例如金額無效，或帳戶不存在）
                {
                    MessageBox.Show(ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex) // 捕獲其他通用錯誤
                {
                    MessageBox.Show($"存款失敗: {ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("請輸入有效的存款金額。", "輸入錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            // 如果沒有客戶帳戶，則直接返回
            if (_customerAccount == null) return;

            // 嘗試解析輸入的金額
            if (decimal.TryParse(txtAmount.Text, out decimal amount) && amount > 0)
            {
                try
                {
                    // 呼叫 AccountService 的取款方法
                    if (_accountService.Withdraw(_customerAccount.Id, amount, _loggedInUser))
                    {
                        MessageBox.Show("取款成功！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadAccountInfo(); // 取款成功後重新載入帳戶資訊和交易記錄
                        txtAmount.Clear(); // 清空輸入框
                    }
                }
                catch (ArgumentException ex) // 捕獲特定類型的錯誤（例如金額無效，或帳戶不存在）
                {
                    MessageBox.Show(ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (InvalidOperationException ex) // 捕獲餘額不足的錯誤
                {
                    MessageBox.Show(ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex) // 捕獲其他通用錯誤
                {
                    MessageBox.Show($"取款失敗: {ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("請輸入有效的取款金額。", "輸入錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}