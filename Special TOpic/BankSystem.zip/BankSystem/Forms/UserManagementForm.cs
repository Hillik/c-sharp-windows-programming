﻿using System;
using System.Linq;
using System.Windows.Forms;
using BankSystem.BLL;
using BankSystem.Models;
using System.Collections.Generic;

namespace BankSystem.Forms
{
    public partial class UserManagementForm : Form
    {
        private User _loggedInUser;
        private UserService _userService;
        private Role _targetRole; // 標示此表單是管理哪種角色 (客戶或職員)

        public UserManagementForm(User user, Role targetRole)
        {
            InitializeComponent();
            _loggedInUser = user;
            _userService = new UserService();
            _targetRole = targetRole;

            InitializeFormByRole();
            LoadUsers();
        }

        private void InitializeFormByRole()
        {
            if (_targetRole == Role.Customer)
            {
                lblTitle.Text = "客戶帳號管理";
                lblRole.Visible = false; // 隱藏角色選擇，因為固定是客戶
                cmbRole.Visible = false;
                // 職員只能新增客戶
                if (_loggedInUser.Role == Role.Clerk)
                {
                    // 職員無法刪除用戶或修改角色，僅能新增客戶
                    btnDeleteUser.Enabled = false;
                    //cmbRole.Enabled = false;
                }
            }
            else if (_targetRole == Role.Clerk)
            {
                lblTitle.Text = "職員帳號管理";
                lblRole.Visible = true; // 顯示角色選擇，因為可以創建職員或副行長
                cmbRole.Visible = true;
                cmbRole.DataSource = Enum.GetValues(typeof(Role))
                                             .Cast<Role>()
                                             .Where(r => r == Role.Clerk || r == Role.VicePresident) // 副行長只能創建職員或副行長
                                             .ToList();
                // 如果是行長，可以創建所有角色
                if (_loggedInUser.Role == Role.President)
                {
                    cmbRole.DataSource = Enum.GetValues(typeof(Role))
                                           .Cast<Role>()
                                           .Where(r => r != Role.Customer) // 行長可以創建職員、副行長、行長
                                           .ToList();
                }

                // 副行長不能刪除比自己權限高的 (行長)
                if (_loggedInUser.Role == Role.VicePresident)
                {
                    // btnDeleteUser.Enabled = false; // 暫時讓副行長可以刪除職員，但不能刪除行長
                }
            }

            // 確保權限：
            // 職員不能新增非客戶
            if (_loggedInUser.Role == Role.Clerk && _targetRole != Role.Customer)
            {
                // 這不應該發生，因為 MainForm 已經限制了導覽
                // 但為了安全，可以禁用所有操作
                btnAddUser.Enabled = false;
                btnDeleteUser.Enabled = false;
                MessageBox.Show("您沒有權限管理此類型的用戶。", "權限不足", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void LoadUsers()
        {
            List<User> users;
            if (_targetRole == Role.Customer)
            {
                users = _userService.GetAllUsers().Where(u => u.Role == Role.Customer).ToList();
            }
            else // targetRole == Role.Clerk (或行長管理職員)
            {
                // 副行長和行長可以看到所有內部員工帳號
                users = _userService.GetAllUsers().Where(u => u.Role >= Role.Clerk).ToList();
                // 但副行長不能看到行長帳號
                if (_loggedInUser.Role == Role.VicePresident)
                {
                    users = users.Where(u => u.Role < Role.President).ToList();
                }
            }

            dataGridViewUsers.DataSource = users;
            // 隱藏敏感資訊或不相關的列
            dataGridViewUsers.Columns["Id"].Visible = false;
            dataGridViewUsers.Columns["PasswordHash"].Visible = false;
            dataGridViewUsers.Columns["Username"].HeaderText = "帳號";
            dataGridViewUsers.Columns["Name"].HeaderText = "姓名";
            dataGridViewUsers.Columns["Role"].HeaderText = "角色";
            dataGridViewUsers.Columns["CreationDate"].HeaderText = "創建日期";
            dataGridViewUsers.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            string name = txtName.Text.Trim();
            Role selectedRole; // 宣告 selectedRole 變數

            // 根據 _targetRole 和 _loggedInUser.Role 來決定 selectedRole 的值
            if (_targetRole == Role.Customer)
            {
                selectedRole = Role.Customer; // 如果目標是客戶管理，則固定為客戶
            }
            else // _targetRole 是 Role.Clerk (職員帳號管理)
            {
                if (_loggedInUser.Role == Role.President || _loggedInUser.Role == Role.VicePresident)
                {
                    // 如果是行長或副行長，則從 cmbRole 獲取選取的角色
                    if (cmbRole.SelectedItem == null)
                    {
                        MessageBox.Show("請選擇一個角色。", "輸入錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    selectedRole = (Role)cmbRole.SelectedItem;
                }
                else // 理論上職員不會進入此分支來新增職員，但為了安全，可以預設
                {
                    selectedRole = _targetRole;
                }
            }

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("請填寫所有欄位：帳號、密碼和姓名。", "輸入錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (_userService.CreateUser(username, password, name, selectedRole, _loggedInUser))
                {
                    MessageBox.Show($"成功創建用戶：{username} ({selectedRole})", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearInputFields();
                    LoadUsers(); // 刷新列表
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"創建用戶失敗: {ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            if (dataGridViewUsers.SelectedRows.Count > 0)
            {
                // 獲取選中的用戶ID
                int selectedUserId = (int)dataGridViewUsers.SelectedRows[0].Cells["Id"].Value;
                string selectedUsername = dataGridViewUsers.SelectedRows[0].Cells["Username"].Value.ToString();

                if (MessageBox.Show($"確定要刪除用戶 {selectedUsername} 嗎？此操作不可逆！", "確認刪除", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    try
                    {
                        if (_userService.DeleteUser(selectedUserId, _loggedInUser))
                        {
                            MessageBox.Show($"用戶 {selectedUsername} 已被成功刪除。", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadUsers(); // 刷新列表
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"刪除用戶失敗: {ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("請選擇一個要刪除的用戶。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }


        private void ClearInputFields()
        {
            txtUsername.Clear();
            txtPassword.Clear();
            txtName.Clear();
            // cmbRole.SelectedIndex = 0; // 可以重置為預設選項
        }
    }
}