﻿using System;
using System.Windows.Forms;

namespace BankSystem.Forms
{
    public partial class AdjustBalanceDialog : Form
    {
        public decimal Amount { get; private set; }
        public string Description { get; private set; }

        public AdjustBalanceDialog()
        {
            InitializeComponent();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (decimal.TryParse(txtAmount.Text, out decimal amount))
            {
                Amount = amount;
                Description = txtDescription.Text.Trim();
                if (string.IsNullOrWhiteSpace(Description))
                {
                    MessageBox.Show("請輸入調整原因。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("請輸入有效的金額。", "輸入錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}