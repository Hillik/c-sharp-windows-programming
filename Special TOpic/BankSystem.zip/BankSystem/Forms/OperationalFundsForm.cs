﻿using System;
using System.Windows.Forms;
using BankSystem.BLL;
using BankSystem.Models;

namespace BankSystem.Forms
{
    public partial class OperationalFundsForm : Form
    {
        private User _loggedInUser;
        private AccountService _accountService;
        private UserService _userService;

        public OperationalFundsForm(User user)
        {
            InitializeComponent();
            _loggedInUser = user;
            _accountService = new AccountService();
            _userService = new UserService();

            if (_loggedInUser.Role != Role.President)
            {
                MessageBox.Show("您沒有權限調整銀行營運資金。", "權限不足", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Controls.Clear();
                return;
            }

            LoadFundsInfo();
        }

        private void LoadFundsInfo()
        {
            decimal currentOperationalFunds = _accountService.GetBankOperationalFunds();
            lblCurrentFunds.Text = $"當前銀行營運資金: {currentOperationalFunds:C2}";
        }

        private void btnAdjustFunds_Click(object sender, EventArgs e)
        {
            if (!decimal.TryParse(txtNewFunds.Text, out decimal newFunds))
            {
                MessageBox.Show("請輸入有效的營運資金金額。", "輸入錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 雙重驗證對話框
            using (DualAuthDialog authDialog = new DualAuthDialog(_loggedInUser))
            {
                if (authDialog.ShowDialog() == DialogResult.OK)
                {
                    User vicePresident = authDialog.VicePresidentUser;
                    string operationDescription = authDialog.OperationDescription;

                    try
                    {
                        // 修正6: 使用重新命名的方法並提供所有必要參數
                        if (_accountService.AdjustBankOperationalFunds(newFunds, _loggedInUser, vicePresident, operationDescription))
                        {
                            MessageBox.Show("銀行營運資金調整成功！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadFundsInfo();
                            txtNewFunds.Clear();
                            txtNewFunds.Focus();
                        }
                    }
                    catch (UnauthorizedAccessException ex)
                    {
                        MessageBox.Show(ex.Message, "權限錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (ArgumentException ex)
                    {
                        MessageBox.Show(ex.Message, "輸入錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"調整失敗: {ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}