﻿using System;
using System.Linq;
using System.Windows.Forms;
using BankSystem.BLL;
using BankSystem.Models;
using System.Collections.Generic;

namespace BankSystem.Forms
{
    public partial class BankOverviewForm : Form
    {
        private User _loggedInUser;
        private AccountService _accountService;
        private UserService _userService; // 用於獲取用戶姓名

        public BankOverviewForm(User user)
        {
            InitializeComponent();
            _loggedInUser = user;
            _accountService = new AccountService();
            _userService = new UserService();

            InitializeFormByRole();
            LoadBankData();
        }

        private void InitializeFormByRole()
        {
            if (_loggedInUser.Role < Role.Clerk)
            {
                MessageBox.Show("您沒有權限查看銀行總覽。", "權限不足", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Controls.Clear(); // 清空介面
                return;
            }

            if (_loggedInUser.Role >= Role.VicePresident)
            {
                lblOperationalFunds.Visible = true;
                lblTotalBankAssets.Visible = true;
                lblTotalBankAssetsTitle.Visible = true;
                lblOperationalFundsTitle.Visible = true;
            }
            else // Clerk
            {
                lblOperationalFunds.Visible = false;
                lblTotalBankAssets.Visible = false;
                lblTotalBankAssetsTitle.Visible = false;
                lblOperationalFundsTitle.Visible = false;
            }
        }

        private void LoadBankData()
        {
            // 加載所有客戶帳戶
            List<Account> accounts = _accountService.GetAllAccounts();

            // 為 DataGridView 準備數據源
            var accountDisplayList = accounts.Select(a => new
            {
                // 通過 UserId 找到對應的 Username 和 Name
                OwnerName = _userService.GetUserById(a.UserId)?.Name,
                a.AccountNumber,
                a.Balance,
                a.CreationDate
            }).ToList();

            dataGridViewAccounts.DataSource = accountDisplayList;

            // 調整 DataGridView 顯示
            dataGridViewAccounts.Columns["OwnerName"].HeaderText = "客戶姓名";
            dataGridViewAccounts.Columns["AccountNumber"].HeaderText = "帳號";
            dataGridViewAccounts.Columns["Balance"].HeaderText = "餘額";
            dataGridViewAccounts.Columns["CreationDate"].HeaderText = "創建日期";
            dataGridViewAccounts.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);


            // 顯示總資產 (僅副行長及以上)
            if (_loggedInUser.Role >= Role.VicePresident)
            {
                decimal totalCustomerBalances = _accountService.GetTotalCustomerBalances();
                decimal operationalFunds = _accountService.GetBankOperationalFunds();
                decimal totalBankAssets = totalCustomerBalances + operationalFunds;

                lblOperationalFunds.Text = $"銀行營運資金: {operationalFunds:C2}";
                lblTotalBankAssets.Text = $"銀行總資產: {totalBankAssets:C2}";
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadBankData();
        }

        private void btnAdjustBalance_Click(object sender, EventArgs e)
        {
            if (dataGridViewAccounts.SelectedRows.Count == 0)
            {
                MessageBox.Show("請選擇一個客戶帳戶來調整餘額。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // 獲取選中的帳戶號碼，然後找到對應的 Account ID
            string selectedAccountNumber = dataGridViewAccounts.SelectedRows[0].Cells["AccountNumber"].Value.ToString();
            Account selectedAccount = _accountService.GetAccountByAccountNumber(selectedAccountNumber);

            if (selectedAccount == null)
            {
                MessageBox.Show("無法找到選中的帳戶資訊。", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 彈出一個對話框讓職員輸入調整金額和原因
            using (AdjustBalanceDialog dialog = new AdjustBalanceDialog())
            {
                dialog.Text = $"調整客戶 {selectedAccountNumber} 餘額";
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    decimal amountChange = dialog.Amount;
                    string description = dialog.Description;

                    try
                    {
                        if (_accountService.AdjustCustomerBalance(selectedAccount.Id, amountChange, _loggedInUser, description))
                        {
                            MessageBox.Show("客戶餘額調整成功！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadBankData(); // 刷新數據
                        }
                    }
                    catch (UnauthorizedAccessException ex)
                    {
                        MessageBox.Show(ex.Message, "權限不足", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"調整失敗: {ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}