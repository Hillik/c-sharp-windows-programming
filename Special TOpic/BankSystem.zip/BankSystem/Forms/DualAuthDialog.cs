﻿using System;
using System.Windows.Forms;
using BankSystem.BLL;
using BankSystem.Models;

namespace BankSystem.Forms
{
    public partial class DualAuthDialog : Form
    {
        private User _loggedInPresident;
        private UserService _userService;

        public User VicePresidentUser { get; private set; } // 用於返回驗證成功的副行長
        public string OperationDescription { get; private set; } // 操作說明

        public DualAuthDialog(User president)
        {
            InitializeComponent();
            _loggedInPresident = president;
            _userService = new UserService();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            string vpUsername = txtVPUsername.Text.Trim();
            string vpPassword = txtVPPassword.Text.Trim();
            string description = txtDescription.Text.Trim();

            if (string.IsNullOrWhiteSpace(vpUsername) || string.IsNullOrWhiteSpace(vpPassword) || string.IsNullOrWhiteSpace(description))
            {
                MessageBox.Show("請輸入副行長帳號、密碼和操作說明。", "輸入錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                User vp = _userService.AuthenticateUser(vpUsername, vpPassword);

                if (vp != null && vp.Role == Role.VicePresident)
                {
                    VicePresidentUser = vp;
                    OperationDescription = description;
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("副行長帳號或密碼錯誤，或該帳號不具備副行長權限。", "驗證失敗", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"驗證過程中發生錯誤: {ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}