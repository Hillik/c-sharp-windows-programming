using System;
using System.Windows.Forms;
using BankSystem.DAL; // �ޤJ DatabaseHelper

namespace BankSystem
{
    static class Program
    {
        /// <summary>
        /// ���ε{�����D�n�i�J�I�C
        /// </summary>
        [STAThread]
        static void Main()
        {
            // �b���ε{���Ұʮɪ�l�Ƹ�Ʈw
            DatabaseHelper.InitializeDatabase();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginForm()); // �ڭ̱N�q LoginForm �}�l
        }
    }
}