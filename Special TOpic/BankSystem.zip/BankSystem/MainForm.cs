﻿using System;
using System.Drawing;
using System.Windows.Forms;
using BankSystem.Models;
using BankSystem.Forms; 

namespace BankSystem
{
    public partial class MainForm : Form
    {
        private User _loggedInUser;
        private Form _currentChildForm; // 用於追蹤當前顯示的子表單

        public MainForm(User user)
        {
            InitializeComponent();
            _loggedInUser = user;
            this.Text = $"銀行系統 - 歡迎 {user.Name} ({user.Role})";

            InitializeMainLayout();
            ShowRoleSpecificFunctions();
        }

        private void InitializeMainLayout()
        {
            // 設置主面板，用於載入子表單
            mainPanel.Dock = DockStyle.Fill;
            mainPanel.BringToFront(); // 確保主面板在導覽面板之上

            // 設置導覽面板和登出按鈕
            panelNavigation.Dock = DockStyle.Left;
            panelNavigation.Width = 200; // 導覽面板寬度
            btnLogout.Dock = DockStyle.Bottom; // 登出按鈕放在底部

            // 調整歡迎訊息位置
            lblWelcomeMessage.Text = $"歡迎回來, {_loggedInUser.Name} ({_loggedInUser.Role})！";
            lblWelcomeMessage.AutoSize = true;
            lblWelcomeMessage.Location = new Point(10, 10); // 調整位置

            // 清除現有按鈕，重新動態添加
            panelNavigation.Controls.Clear();
            panelNavigation.Controls.Add(btnLogout); // 登出按鈕
            panelNavigation.Controls.Add(lblWelcomeMessage); // 歡迎訊息
        }

        private void ShowRoleSpecificFunctions()
        {
            // 只有客戶才需要個人帳戶功能
            if (_loggedInUser.Role == Role.Customer)
            {
                AddNavigationButton("個人帳戶", btnCustomerAccount_Click);
            }

            if (_loggedInUser.Role >= Role.Clerk) // 職員及以上
            {
                AddNavigationButton("客戶管理", btnCustomerManagement_Click);
            }
            if (_loggedInUser.Role >= Role.VicePresident) // 副行長及以上
            {
                AddNavigationButton("銀行總覽", btnBankOverview_Click);
                AddNavigationButton("職員管理", btnClerkManagement_Click);
            }
            if (_loggedInUser.Role >= Role.President) // 行長及以上
            {
                AddNavigationButton("營運資金調整", btnOperationalFundsAdjustment_Click);
                AddNavigationButton("審計日誌", btnAuditLog_Click);
            }
        }

        private void AddNavigationButton(string text, EventHandler clickHandler)
        {
            Button btn = new Button();
            btn.Text = text;
            btn.Tag = text; // 可以用來識別按鈕
            btn.Dock = DockStyle.Top;
            btn.Height = 50;
            btn.Font = new Font("微軟正黑體", 12, FontStyle.Bold);
            btn.BackColor = Color.FromArgb(70, 70, 70); // 深灰色
            btn.ForeColor = Color.White; // 白色文字
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += clickHandler;
            panelNavigation.Controls.Add(btn);

            // 為了讓按鈕從上到下排列，需要逆序添加，或者使用 TableLayoutPanel/FlowLayoutPanel
            // 這裡簡單處理，加一個 Panel 來包裝按鈕，讓它們從上到下堆疊
            panelNavigation.Controls.SetChildIndex(btn, 0); // 讓新加的按鈕顯示在最上方
        }

        private void OpenChildForm(Form childForm)
        {
            if (_currentChildForm != null)
            {
                _currentChildForm.Close(); // 關閉之前的子表單
            }
            _currentChildForm = childForm;
            childForm.TopLevel = false; // 設置為非頂級表單
            childForm.FormBorderStyle = FormBorderStyle.None; // 移除邊框
            childForm.Dock = DockStyle.Fill; // 填滿父容器
            mainPanel.Controls.Add(childForm); // 將子表單添加到主面板
            mainPanel.Tag = childForm; // 設置Tag，方便獲取
            childForm.BringToFront(); // 確保子表單在最上層
            childForm.Show();
        }

        // --- 導覽按鈕點擊事件 ---
        private void btnCustomerAccount_Click(object sender, EventArgs e)
        {
            OpenChildForm(new CustomerAccountForm(_loggedInUser));
        }

        private void btnCustomerManagement_Click(object sender, EventArgs e)
        {
            OpenChildForm(new UserManagementForm(_loggedInUser, Role.Customer)); // 職員只能管理客戶
        }

        private void btnClerkManagement_Click(object sender, EventArgs e)
        {
            OpenChildForm(new UserManagementForm(_loggedInUser, Role.Clerk)); // 副行長管理職員
        }

        private void btnBankOverview_Click(object sender, EventArgs e)
        {
            OpenChildForm(new BankOverviewForm(_loggedInUser));
        }

        private void btnOperationalFundsAdjustment_Click(object sender, EventArgs e)
        {
            OpenChildForm(new OperationalFundsForm(_loggedInUser));
        }

        private void btnAuditLog_Click(object sender, EventArgs e)
        {
            OpenChildForm(new AuditLogForm(_loggedInUser));
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("確定要登出嗎？", "登出確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide();
                LoginForm loginForm = new LoginForm();
                loginForm.Closed += (s, args) => this.Close(); // 當登入表單關閉時，關閉應用程式
                loginForm.Show();
            }
        }
    }
}