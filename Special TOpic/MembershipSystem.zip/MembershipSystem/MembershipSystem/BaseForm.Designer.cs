﻿// BaseForm.Designer.cs
using System.Windows.Forms; // 需要引用 Windows Forms 的命名空間

namespace MembershipSystem // ***請替換為您專案實際使用的 Namespace***
{
    // 使用 partial 關鍵字，表示 BaseForm 類別的定義分散在多個檔案中
    // [類別與物件 (Class and Object)] - BaseForm 的另一部分定義
    public partial class BaseForm : Form // 這裡通常會指定它繼承自 Form，與 BaseForm.cs 中的定義一致
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        // [類別與物件 (Class and Object)] - 定義一個用於存放組件的容器
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        // [類別與物件 (Class and Object)] - 覆寫 Dispose 方法來釋放資源
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        // [類別與物件 (Class and Object)] - 定義初始化組件的方法
        private void InitializeComponent()
        {
            // 這個方法通常由設計器自動生成，用於初始化控制項。
            // 對於基類，這裡可以放一些子類別共用的基本視窗設定。
            // 例如：
            this.SuspendLayout();
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F); // 預設縮放比例
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font; // 預設自動縮放模式
            this.ClientSize = new System.Drawing.Size(400, 300); // 預設視窗大小
            this.Name = "BaseForm"; // 基類的名稱
            this.Text = "會員系統"; // 預設視窗標題
            // 如果您有設定其他共用的屬性，例如 Icon 或 StartPosition，也可以放在這裡
            // this.Icon = ((System.Drawing.Icon)(/* 從資源載入或 null */ null));
            // this.StartPosition = FormStartPosition.CenterScreen;
            this.ResumeLayout(false);
        }

        #endregion

        // 注意：通常基類在 Designer.cs 中不需要宣告控制項成員，
        // 因為控制項是放在繼承它的子類別上的。
        // 所有共用的控制項成員應該在 BaseForm.cs 中以 protected 關鍵字宣告。
    }
}