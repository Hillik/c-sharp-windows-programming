﻿// RegistrationForm.cs
using MembershipSystem; // 確保使用正確的 Namespace
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MembershipSystem // 統一 Namespace
{
    // [繼承 (Inheritance)] - 繼承自 BaseForm
    // [類別與物件 (Class and Object)] - RegistrationForm 類別本身
    public partial class RegistrationForm : BaseForm
    {
        // 建構函式：接收 IUserRepository 實例並傳遞給基類
        // [多型 (Polymorphism)] - 接收 IUserRepository 介面型別
        public RegistrationForm(IUserRepository userRepository)
            : base(userRepository) // ***呼叫基類建構函式***
        {
            InitializeComponent(); // 初始化設計器生成的控制項
            this.Text = "會員註冊"; // 設定視窗標題
            // 假設您在 Designer 中有 txtPassword 和 txtConfirmPassword TextBox
            txtPassword.UseSystemPasswordChar = true; // 隱藏密碼字元
            txtConfirmPassword.UseSystemPasswordChar = true; // 隱藏密碼字元
        }

        // "註冊" 按鈕點擊事件處理函式
        // [類別與物件 (Class and Object)] - 事件處理函式
        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();             // 假設有 txtUsername TextBox
            string password = txtPassword.Text;                 // 假設有 txtPassword TextBox
            string confirmPassword = txtConfirmPassword.Text;     // 假設有 txtConfirmPassword TextBox
            string email = txtEmail.Text.Trim();                 // 假設有 txtEmail TextBox (Email 是可選的)

            // [例外處理 (Exception Handling)] - 基本輸入驗證
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(confirmPassword))
            {
                ShowErrorMessage("使用者名稱、密碼和確認密碼不能為空。");
                return;
            }

            if (password != confirmPassword)
            {
                ShowErrorMessage("密碼和確認密碼不匹配。");
                return;
            }

            // 在背景執行緒中執行資料庫操作
            // [執行緒 (Thread)] - Task.Run
            Task.Run(() =>
            {
                bool success = false;
                string errorMessage = null;

                // [例外處理 (Exception Handling)] - 捕獲資料庫操作例外
                try
                {
                    // 創建新的 User 物件 (使用過載建構函式)
                    // [過載 (Overloading)] - 調用 User(string username, string password) 建構函式
                    // [類別與物件 (Class and Object)] - 創建 User 物件
                    User newUser = new User(username, password)
                    {
                        Email = string.IsNullOrWhiteSpace(email) ? null : email // 如果 Email 為空或空白，設為 null
                    };

                    // 調用 UserRepository 的 AddUser 方法
                    // [多型 (Polymorphism)] - 透過 _userRepository (IUserRepository 型別) 調用實作類別的方法
                    success = _userRepository.AddUser(newUser);
                }
                catch (ApplicationException appEx) // 捕獲我們在 Repository 中拋出的應用程式例外 (例如使用者名稱重複)
                {
                    errorMessage = appEx.Message;
                }
                catch (Exception ex) // 捕獲其他未知例外
                {
                    errorMessage = $"註冊時發生未知錯誤: {ex.Message}";
                }

                // 回到 UI 執行緒更新介面
                // [委派 (Delegate)] - MethodInvoker
                // [執行緒 (Thread)] - Invoke
                this.Invoke((MethodInvoker)delegate
                {
                    if (errorMessage != null)
                    {
                        ShowErrorMessage(errorMessage);
                    }
                    else if (success)
                    {
                        ShowInfoMessage("註冊成功！您現在可以登入了。", "成功");
                        this.Close(); // 註冊成功後關閉註冊視窗 (會觸發開啟它的視窗的 FormClosed 事件，例如 LoginForm 或 MainForm)
                    }
                    else
                    {
                        // 如果 AddUser 返回 false 但沒有拋出例外，可能是其他邏輯問題
                        ShowErrorMessage("註冊失敗，請稍後再試。");
                    }
                });
            });
        }

        // RegistrationForm 本身不需要特別處理例外，因為資料庫操作都在 Repository 中
    }
}