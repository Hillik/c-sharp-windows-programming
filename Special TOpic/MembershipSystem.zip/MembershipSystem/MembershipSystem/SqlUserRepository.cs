﻿// SqlUserRepository.cs
using System;
using System.Data;
using System.Data.SqlClient;

namespace MembershipSystem
{
    /// <summary>
    /// 使用 SQL Server 實作 IUserRepository 介面
    /// </summary>
    // [類別與物件 (Class and Object)]
    // [實作介面 (Implements Interface)]
    public class SqlUserRepository : IUserRepository
    {
        private readonly string _connectionString;

        // 建構函式：接收資料庫連線字串
        public SqlUserRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        /// <summary>
        /// 實作介面的 AddUser 方法
        /// </summary>
        // [實作介面方法 (Implementing Interface Method)]
        public bool AddUser(User user)
        {
            // [例外處理 (Exception Handling)]
            try
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO Users (Username, Password, Email, RegistrationDate) VALUES (@Username, @Password, @Email, GETDATE())";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Username", user.Username);
                        cmd.Parameters.AddWithValue("@Password", user.Password);
                        cmd.Parameters.AddWithValue("@Email", (object)user.Email ?? DBNull.Value); // 處理可為 null 的 Email

                        int result = cmd.ExecuteNonQuery();
                        return result > 0;
                    }
                }
            }
            catch (SqlException ex)
            {
                // 捕獲 SQL 錯誤，特別處理重複使用者名稱的錯誤 (ErrorCode 2627)
                // [例外處理 (Exception Handling)]
                if (ex.Number == 2627) // Unique constraint violation
                {
                    throw new ApplicationException("Username already exists."); // 拋出應用程式層級的例外
                }
                else
                {
                    throw new ApplicationException($"Database error during registration: {ex.Message}", ex); // 拋出其他資料庫錯誤
                }
            }
            catch (Exception ex)
            {
                // 捕獲其他未知錯誤
                // [例外處理 (Exception Handling)]
                throw new ApplicationException($"An unexpected error occurred during registration: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// 實作介面的 GetUserByUsername 方法
        /// </summary>
        // [實作介面方法 (Implementing Interface Method)]
        public User GetUserByUsername(string username)
        {
            // [例外處理 (Exception Handling)]
            try
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    string query = "SELECT UserId, Username, Password, Email, RegistrationDate FROM Users WHERE Username = @Username";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Username", username);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                // 使用 User 類別的過載建構函式來創建物件
                                // [過載 (Overloading)]
                                return new User(
                                    reader.GetInt32(reader.GetOrdinal("UserId")),
                                    reader.GetString(reader.GetOrdinal("Username")),
                                    reader.GetString(reader.GetOrdinal("Password")),
                                    reader.IsDBNull(reader.GetOrdinal("Email")) ? null : reader.GetString(reader.GetOrdinal("Email")),
                                    reader.GetDateTime(reader.GetOrdinal("RegistrationDate"))
                                );
                            }
                            return null; // 找不到使用者
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // 捕獲資料庫錯誤
                // [例外處理 (Exception Handling)]
                throw new ApplicationException($"Database error retrieving user: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// 實作介面的 ValidateUser 方法
        /// </summary>
        // [實作介面方法 (Implementing Interface Method)]
        public bool ValidateUser(string username, string password)
        {
            // [例外處理 (Exception Handling)]
            try
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    // 注意：實際應用不應直接比較明文密碼，應比較雜湊值
                    string query = "SELECT COUNT(1) FROM Users WHERE Username = @Username AND Password = @Password";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Username", username);
                        cmd.Parameters.AddWithValue("@Password", password);

                        int count = (int)cmd.ExecuteScalar();
                        return count > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                // 捕獲資料庫錯誤
                // [例外處理 (Exception Handling)]
                throw new ApplicationException($"Database error during validation: {ex.Message}", ex);
            }
        }
    }
}