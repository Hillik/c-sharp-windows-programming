﻿// DashboardForm.Designer.cs
namespace MembershipSystem // 確保使用正確的 Namespace
{
    // [類別與物件 (Class and Object)] - DashboardForm 的部分定義
    public partial class DashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnViewProfile = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            //
            // lblWelcome
            //
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.Location = new System.Drawing.Point(30, 40);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(150, 29); // 估計大小
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "歡迎，[使用者]！"; // 程式碼中會設定實際名稱
            //
            // btnViewProfile
            //
            this.btnViewProfile.Location = new System.Drawing.Point(30, 100);
            this.btnViewProfile.Name = "btnViewProfile";
            this.btnViewProfile.Size = new System.Drawing.Size(150, 40);
            this.btnViewProfile.TabIndex = 1;
            this.btnViewProfile.Text = "查看個人資料";
            this.btnViewProfile.UseVisualStyleBackColor = true;
            // 事件處理函式在 DashboardForm.cs 中
            // this.btnViewProfile.Click += new System.EventHandler(this.btnViewProfile_Click);
            //
            // btnLogout
            //
            this.btnLogout.Location = new System.Drawing.Point(30, 160);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(150, 40);
            this.btnLogout.TabIndex = 2;
            this.btnLogout.Text = "登出";
            this.btnLogout.UseVisualStyleBackColor = true;
            // 事件處理函式在 DashboardForm.cs 中
            // this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            //
            // DashboardForm
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 250); // 調整視窗大小
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnViewProfile);
            this.Controls.Add(this.lblWelcome);
            this.Name = "DashboardForm";
            this.Text = "會員儀表板"; // 視窗標題
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        // [類別與物件 (Class and Object)] - 定義 Form 上的控制項成員
        private System.Windows.Forms.Label lblWelcome; // 歡迎訊息 Label
        private System.Windows.Forms.Button btnViewProfile; // 查看個人資料按鈕
        private System.Windows.Forms.Button btnLogout; // 登出按鈕
    }
}