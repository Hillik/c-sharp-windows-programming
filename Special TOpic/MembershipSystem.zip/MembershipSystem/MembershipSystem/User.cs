﻿// User.cs
using System;

namespace MembershipSystem
{
    /// <summary>
    /// 代表一個會員的類別
    /// </summary>
    public class User
    {
        // 屬性：儲存會員資料
        public int UserId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; } // 實際應用請使用安全雜湊
        public string Email { get; set; }
        public DateTime RegistrationDate { get; set; }

        // 過載的建構函式 1：用於創建一個新的、尚未有 UserId 的 User 物件 (例如註冊時)
        // [過載 (Overloading)]
        public User(string username, string password)
        {
            Username = username;
            Password = password;
            // UserId 和 RegistrationDate 將由資料庫生成
        }

        // 過載的建構函式 2：用於從資料庫讀取現有的 User 物件 (例如登入後載入資料)
        // [過載 (Overloading)]
        public User(int userId, string username, string password, string email, DateTime registrationDate)
        {
            UserId = userId;
            Username = username;
            Password = password;
            Email = email;
            RegistrationDate = registrationDate;
        }

        // 類別 (Class) 的基本結構
    }
}