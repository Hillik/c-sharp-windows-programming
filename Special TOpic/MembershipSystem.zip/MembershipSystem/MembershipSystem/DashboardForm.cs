﻿// DashboardForm.cs
using MembershipSystem; // 確保使用正確的 Namespace
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MembershipSystem // 統一 Namespace
{
    // [繼承 (Inheritance)] - 繼承自 BaseForm
    // [類別與物件 (Class and Object)] - DashboardForm 類別本身
    public partial class DashboardForm : BaseForm
    {
        private string _loggedInUsername; // 儲存登入的使用者名稱 (String 是物件)

        // 建構函式：接收 IUserRepository 和已登入的使用者名稱
        // [多型 (Polymorphism)] - 接收 IUserRepository 介面型別
        public DashboardForm(IUserRepository userRepository, string username)
            : base(userRepository) // ***呼叫基類建構函式***
        {
            InitializeComponent(); // 初始化設計器生成的控制項

            _loggedInUsername = username; // 儲存傳入的使用者名稱
            this.Text = "會員儀表板"; // 設定視窗標題

            // 在 Label 中顯示歡迎訊息 (假設您有一個名為 lblWelcome 的 Label)
            // [類別與物件 (Class and Object)] - 存取 this (DashboardForm 物件) 和 lblWelcome (Label 物件) 的屬性
            if (lblWelcome != null) // 檢查 Label 是否存在
            {
                lblWelcome.Text = $"歡迎，{_loggedInUsername}！";
            }
        }

        // "查看個人資料" 按鈕點擊事件處理函式
        // [類別與物件 (Class and Object)] - 事件處理函式
        private void btnViewProfile_Click(object sender, EventArgs e)
        {
            // 創建 UserProfileForm 實例，並傳遞 UserRepository 和使用者名稱
            // [多型 (Polymorphism)] - 將 _userRepository (IUserRepository 型別) 傳遞給 UserProfileForm
            // [類別與物件 (Class and Object)] - 創建新的 UserProfileForm 物件
            UserProfileForm profileForm = new UserProfileForm(_userRepository, _loggedInUsername);

            // 使用 ShowDialog() 會阻擋當前視窗的操作直到 UserProfileForm 關閉
            // [執行緒 (Thread)] - ShowDialog() 在內部處理訊息迴圈，是阻塞的
            profileForm.ShowDialog();
        }

        // "登出" 按鈕點擊事件處理函式
        // [類別與物件 (Class and Object)] - 事件處理函式
        private void btnLogout_Click(object sender, EventArgs e)
        {
            // 執行登出操作 (在這裡主要是關閉當前視窗)
            // 如果需要，清除記憶體中的使用者資訊 (例如 token 或 session ID，本例中是 _loggedInUsername)
            _loggedInUsername = null; // 清除使用者名稱 (簡單示範)

            // 關閉當前表單 (DashboardForm)
            // [類別與物件 (Class and Object)] - 調用 this (DashboardForm 物件) 的 Close() 方法
            this.Close();

            // 關於回到登入頁面：關閉 DashboardForm 會觸發開啟它的視窗（通常是 LoginForm）的 FormClosed 事件。
            // 您需要在 LoginForm 的 FormClosed 事件處理函式中，決定是否重新顯示 LoginForm。
            // 如果 LoginForm 使用 ShowDialog() 開啟 DashboardForm，那麼 DashboardForm 關閉後，LoginForm 會自動重新啟用。
        }

        // DashboardForm 本身不需要特別處理例外，因為資料庫操作都在 Repository 和 UserProfileForm 中
    }
}