﻿// MainForm.Designer.cs
namespace MembershipSystem // 確保使用正確的 Namespace
{
    // [類別與物件 (Class and Object)] - MainForm 的部分定義
    public partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLogin = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.SuspendLayout();
            //
            // btnLogin
            //
            this.btnLogin.Location = new System.Drawing.Point(80, 100);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(120, 40);
            this.btnLogin.TabIndex = 0;
            this.btnLogin.Text = "登入";
            this.btnLogin.UseVisualStyleBackColor = true;
            // 事件處理函式通常在 MainForm.cs 中手動添加或由設計器鏈接
            // this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            //
            // btnRegister
            //
            this.btnRegister.Location = new System.Drawing.Point(80, 160);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(120, 40);
            this.btnRegister.TabIndex = 1;
            this.btnRegister.Text = "註冊";
            this.btnRegister.UseVisualStyleBackColor = true;
            // 事件處理函式通常在 MainForm.cs 中手動添加或由設計器鏈接
            // this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            //
            // lblTitle
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(40, 30);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(200, 31); // 估計大小
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "會員系統主頁";
            //
            // MainForm
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(280, 250); // 調整視窗大小
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.btnLogin);
            this.Name = "MainForm";
            this.Text = "會員系統"; // 視窗標題
            this.ResumeLayout(false);
            this.PerformLayout(); // 通常會包含

        }

        #endregion

        // [類別與物件 (Class and Object)] - 定義 Form 上的控制項成員
        private System.Windows.Forms.Button btnLogin; // 登入按鈕
        private System.Windows.Forms.Button btnRegister; // 註冊按鈕
        private System.Windows.Forms.Label lblTitle; // 標題 Label
    }
}