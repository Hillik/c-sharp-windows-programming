﻿// MainForm.cs
using System;
using System.Windows.Forms;
using MembershipSystem; // 確保使用正確的 Namespace
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MembershipSystem // 統一 Namespace
{
    // [繼承 (Inheritance)] - 繼承自 BaseForm
    // [類別與物件 (Class and Object)] - MainForm 類別本身
    public partial class MainForm : BaseForm
    {
        // 建構函式：接收 IUserRepository 實例並傳遞給基類
        // [多型 (Polymorphism)] - 接收 IUserRepository 介面型別
        public MainForm(IUserRepository userRepository)
            : base(userRepository) // ***呼叫基類建構函式***
        {
            InitializeComponent(); // 初始化設計器生成的控制項

            // 設定視窗標題或其他初始化設定
            this.Text = "會員系統 - 首頁";
            // 假設您在 Designer 中有一個 lblTitle Label 來顯示標題
            // lblTitle.Text = "歡迎使用會員系統";
        }

        // "登入" 按鈕點擊事件處理函式
        // [類別與物件 (Class and Object)] - 事件處理函式也是類別的方法
        private void btnLogin_Click(object sender, EventArgs e)
        {
            // 創建 LoginForm 實例，並傳遞 UserRepository 實例
            // [多型 (Polymorphism)] - 將 _userRepository (IUserRepository 型別) 傳遞給 LoginForm
            // [類別與物件 (Class and Object)] - 創建新的 LoginForm 物件
            LoginForm loginForm = new LoginForm(_userRepository);

            // 隱藏當前視窗，顯示登入視窗
            this.Hide();
            // 使用 FormClosed 事件，當登入視窗關閉時重新顯示主視窗
            // [委派 (Delegate)] - FormClosed 是一個事件，其底層使用委派
            loginForm.FormClosed += (s, args) => this.Show(); // 當 loginForm 關閉時，執行 lambda 委派中的程式碼

            loginForm.Show(); // 顯示登入視窗
        }

        // "註冊" 按鈕點擊事件處理函式
        private void btnRegister_Click(object sender, EventArgs e)
        {
            // 創建 RegistrationForm 實例，並傳遞 UserRepository 實例
            // [多型 (Polymorphism)] - 將 _userRepository (IUserRepository 型別) 傳遞給 RegistrationForm
            // [類別與物件 (Class and Object)] - 創建新的 RegistrationForm 物件
            RegistrationForm regForm = new RegistrationForm(_userRepository);

            // 隱藏當前視窗，顯示註冊視窗
            this.Hide();
            // 使用 FormClosed 事件，當註冊視窗關閉時重新顯示主視窗
            // [委派 (Delegate)] - FormClosed 事件
            regForm.FormClosed += (s, args) => this.Show(); // 當 regForm 關閉時，執行 lambda 委派中的程式碼

            regForm.Show(); // 顯示註冊視窗
        }

        // 這個 MainForm 本身不需要特別處理例外，因為資料庫操作都在 Repository 和其他 Forms 中處理
    }
}