﻿// LoginForm.Designer.cs
namespace MembershipSystem // 確保使用正確的 Namespace
{
    // [類別與物件 (Class and Object)] - LoginForm 的部分定義
    public partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblUsername = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.btnGoToRegister = new System.Windows.Forms.Button(); // 新增按鈕，從登入頁面去註冊
            this.SuspendLayout();
            //
            // lblUsername
            //
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new System.Drawing.Point(30, 40);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(82, 17); // 估計大小
            this.lblUsername.TabIndex = 0;
            this.lblUsername.Text = "使用者名稱:";
            //
            // txtUsername
            //
            this.txtUsername.Location = new System.Drawing.Point(130, 40);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(150, 22);
            this.txtUsername.TabIndex = 1;
            //
            // lblPassword
            //
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(30, 80);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(42, 17); // 估計大小
            this.lblPassword.TabIndex = 2;
            this.lblPassword.Text = "密碼:";
            //
            // txtPassword
            //
            this.txtPassword.Location = new System.Drawing.Point(130, 80);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(150, 22);
            this.txtPassword.TabIndex = 3;
            this.txtPassword.UseSystemPasswordChar = true; // 隱藏密碼字元
            //
            // btnLogin
            //
            this.btnLogin.Location = new System.Drawing.Point(160, 130);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(120, 30);
            this.btnLogin.TabIndex = 4;
            this.btnLogin.Text = "登入";
            this.btnLogin.UseVisualStyleBackColor = true;
            // 事件處理函式在 LoginForm.cs 中
            // this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            //
            // btnGoToRegister
            //
            this.btnGoToRegister.Location = new System.Drawing.Point(30, 130);
            this.btnGoToRegister.Name = "btnGoToRegister";
            this.btnGoToRegister.Size = new System.Drawing.Size(120, 30);
            this.btnGoToRegister.TabIndex = 5;
            this.btnGoToRegister.Text = "註冊新帳號";
            this.btnGoToRegister.UseVisualStyleBackColor = true;
            // 事件處理函式在 LoginForm.cs 中
            // this.btnGoToRegister.Click += new System.EventHandler(this.btnGoToRegister_Click);
            //
            // LoginForm
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(330, 190); // 調整視窗大小
            this.Controls.Add(this.btnGoToRegister);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.lblUsername);
            this.Name = "LoginForm";
            this.Text = "會員登入"; // 視窗標題
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        // [類別與物件 (Class and Object)] - 定義 Form 上的控制項成員
        private System.Windows.Forms.Label lblUsername; // 使用者名稱 Label
        private System.Windows.Forms.TextBox txtUsername; // 使用者名稱 TextBox
        private System.Windows.Forms.Label lblPassword; // 密碼 Label
        private System.Windows.Forms.TextBox txtPassword; // 密碼 TextBox
        private System.Windows.Forms.Button btnLogin; // 登入按鈕
        private System.Windows.Forms.Button btnGoToRegister; // 前往註冊按鈕
    }
}