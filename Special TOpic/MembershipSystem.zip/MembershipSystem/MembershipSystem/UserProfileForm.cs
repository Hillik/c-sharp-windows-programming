﻿// UserProfileForm.cs
using MembershipSystem; // 確保使用正確的 Namespace
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MembershipSystem // 統一 Namespace
{
    // [繼承 (Inheritance)] - 繼承自 BaseForm
    // [類別與物件 (Class and Object)] - UserProfileForm 類別本身
    public partial class UserProfileForm : BaseForm
    {
        private string _username; // 要顯示資料的使用者名稱
        private User? _currentUser; // 儲存從資料庫獲取的會員物件 (可為 Null)

        // 建構函式：接收 IUserRepository 和使用者名稱
        // [多型 (Polymorphism)] - 接收 IUserRepository 介面型別
        public UserProfileForm(IUserRepository userRepository, string username)
            : base(userRepository) // ***呼叫基類建構函式***
        {
            InitializeComponent(); // 初始化設計器生成的控制項

            _username = username; // 儲存使用者名稱
            this.Text = "會員資料"; // 設定視窗標題

            // 在表單載入後異步載入使用者資料
            // [類別與物件 (Class and Object)] - Form 的 Load 事件
            this.Load += UserProfileForm_Load;
        }

        // 表單載入事件的異步處理函式
        // 使用 async 關鍵字，允許在方法內部使用 await
        private async void UserProfileForm_Load(object sender, EventArgs e)
        {
            // 禁用控制項或顯示載入指示器 (可選)
            this.Cursor = Cursors.WaitCursor;
            // lblStatus.Text = "載入中..."; // 如果有狀態 Label

            // 在背景執行緒中執行資料庫查詢
            // [執行緒 (Thread)] - Task.Run 將工作提交到執行緒池
            // [委派/執行緒 (Delegate/Thread)] - await 處理從背景執行緒回到 UI 執行緒，更新 UI 時不再需要手動 Invoke
            // [例外處理 (Exception Handling)] - 捕獲異步操作中的例外
            try
            {
                // 使用 await 等待 Task.Run 中的資料庫操作完成
                // [多型 (Polymorphism)] - 透過 _userRepository (IUserRepository 型別) 調用實作類別的方法
                _currentUser = await Task.Run(() => _userRepository.GetUserByUsername(_username));

                // await Task.Run 完成後，程式碼會自動回到 UI 執行緒

                if (_currentUser != null) // 檢查是否找到了使用者
                {
                    // 更新 UI 控制項以顯示使用者資料
                    // [類別與物件 (Class and Object)] - 存取 _currentUser 物件的屬性，並更新 UI 控制項的屬性
                    // 假設您在 Designer 中有 txtUsername, txtEmail TextBox 和 lblRegistrationDate Label
                    if (txtUsername != null) txtUsername.Text = _currentUser.Username;
                    if (txtEmail != null) txtEmail.Text = _currentUser.Email; // Email 現在是 string?，可以直接賦值給 Text
                    if (lblRegistrationDate != null) lblRegistrationDate.Text = $"註冊日期: {_currentUser.RegistrationDate:yyyy-MM-dd HH:mm}"; // 格式化日期
                    // 如果您想讓 Email 和 Username 可以編輯，將 TextBox 的 ReadOnly 屬性設為 false
                }
                else
                {
                    // 如果找不到使用者（理論上登入成功後應該找得到，除非資料被刪除）
                    ShowErrorMessage("無法載入使用者資料。");
                    this.Close(); // 關閉表單
                }
            }
            catch (ApplicationException appEx) // 捕獲從 Repository 拋出的應用程式例外
            {
                ShowErrorMessage($"載入個人資料時發生錯誤: {appEx.Message}");
                this.Close();
            }
            catch (Exception ex) // 捕獲其他未知例外
            {
                ShowErrorMessage($"載入個人資料時發生未知錯誤: {ex.Message}");
                this.Close();
            }
            finally
            {
                // 無論成功或失敗，都恢復鼠標和狀態指示器 (如果有的話)
                this.Cursor = Cursors.Default;
                // if (lblStatus != null) lblStatus.Text = "";
            }
        }

        // "關閉" 按鈕點擊事件處理函式 (假設您在 Designer 中有 btnClose Button)
        // [類別與物件 (Class and Object)] - 事件處理函式
        private void btnClose_Click(object sender, EventArgs e)
        {
            // [類別與物件 (Class and Object)] - 調用 this (UserProfileForm 物件) 的 Close() 方法
            this.Close(); // 關閉當前視窗
        }

        // 如果您實現了編輯功能，需要一個 "儲存" 按鈕及其點擊事件處理函式
        /*
        private async void btnSave_Click(object sender, EventArgs e)
        {
             // 驗證輸入...
             if (_currentUser != null)
             {
                 // 更新 _currentUser 物件的屬性...
                 _currentUser.Email = txtEmail.Text.Trim(); // 假設 Email 可編輯

                 try
                 {
                     // 在背景執行緒中更新資料庫
                     await Task.Run(() => _userRepository.UpdateUser(_currentUser)); // 需要在 IUserRepository 和 SqlUserRepository 中實作 UpdateUser 方法
                     ShowInfoMessage("資料已儲存。", "成功");
                 }
                 catch (Exception ex)
                 {
                      ShowErrorMessage($"儲存資料時發生錯誤: {ex.Message}");
                 }
             }
        }
        */
    }
}