﻿// LoginForm.cs 
using MembershipSystem; // 確保使用正確的 Namespace
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MembershipSystem // 統一 Namespace
{
    // [繼承 (Inheritance)] - 繼承自 BaseForm
    // [類別與物件 (Class and Object)] - LoginForm 類別本身
    public partial class LoginForm : BaseForm
    {
        // 建構函式：接收 IUserRepository 實例並傳遞給基類
        // [多型 (Polymorphism)] - 接收 IUserRepository 介面型別
        public LoginForm(IUserRepository userRepository)
            : base(userRepository) // ***呼叫基類建構函式***
        {
            InitializeComponent(); // 初始化設計器生成的控制項
            this.Text = "會員登入"; // 設定視窗標題
        }

        // "登入" 按鈕點擊事件處理函式
        // [類別與物件 (Class and Object)] - 事件處理函式
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim(); // 假設有 txtUsername TextBox
            string password = txtPassword.Text;     // 假設有 txtPassword TextBox

            // [例外處理 (Exception Handling)] - 基本輸入驗證
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                ShowErrorMessage("請輸入使用者名稱和密碼。"); // 使用基類提供的共用方法
                return;
            }

            // 在背景執行緒中執行資料庫操作，避免 UI 凍結
            // [執行緒 (Thread)] - Task.Run 會使用執行緒池中的執行緒
            Task.Run(() =>
            {
                bool isValid = false;
                string errorMessage = null;

                // [例外處理 (Exception Handling)] - 捕獲資料庫操作中可能發生的例外
                try
                {
                    // 調用 UserRepository 的 ValidateUser 方法
                    // [多型 (Polymorphism)] - 透過 _userRepository (IUserRepository 型別) 調用實作類別的方法
                    isValid = _userRepository.ValidateUser(username, password);
                }
                catch (ApplicationException appEx) // 捕獲我們在 Repository 中拋出的應用程式例外
                {
                    errorMessage = appEx.Message;
                }
                catch (Exception ex) // 捕獲其他未知例外
                {
                    errorMessage = $"登入時發生未知錯誤: {ex.Message}";
                }

                // 回到 UI 執行緒更新介面 (例如顯示訊息、開啟新視窗)
                // [委派 (Delegate)] - MethodInvoker 是一個方便的委派，用於指向 UI 執行緒上的無參數方法
                // [執行緒 (Thread)] - Invoke 在 UI 執行緒上同步執行指定的委派
                this.Invoke((MethodInvoker)delegate
                {
                    if (errorMessage != null)
                    {
                        ShowErrorMessage(errorMessage); // 使用基類方法顯示錯誤
                    }
                    else if (isValid)
                    {
                        ShowInfoMessage("登入成功！", "成功"); // 使用基類方法顯示資訊

                        // 開啟 DashboardForm
                        // [多型 (Polymorphism)] - 將 _userRepository 傳遞給 DashboardForm
                        // [類別與物件 (Class and Object)] - 創建新的 DashboardForm 物件
                        DashboardForm dashboardForm = new DashboardForm(_userRepository, username);

                        // 隱藏當前登入視窗
                        this.Hide();

                        // 如果您希望儀表板關閉後回到登入頁面，可以這樣處理：
                        // dashboardForm.FormClosed += (s, args) => this.Show(); // 當 dashboardForm 關閉時，顯示登入視窗
                        dashboardForm.Show(); // 顯示儀表板視窗

                        // 或者直接關閉登入視窗，讓開啟它的視窗（MainForm 或 Program.cs）決定下一步
                        // this.Close();
                    }
                    else
                    {
                        ShowErrorMessage("使用者名稱或密碼無效。");
                    }
                });
            });
        }

        // "註冊新帳號" 按鈕點擊事件處理函式 (假設您在 Designer 中有 btnGoToRegister Button)
        private void btnGoToRegister_Click(object sender, EventArgs e)
        {
            // 創建 RegistrationForm 實例，並傳遞 UserRepository 實例
            // [多型 (Polymorphism)]
            RegistrationForm regForm = new RegistrationForm(_userRepository);

            // 隱藏登入視窗，顯示註冊視窗
            this.Hide();
            // 使用 FormClosed 事件，當註冊視窗關閉時重新顯示登入視窗
            // [委派 (Delegate)]
            regForm.FormClosed += (s, args) => this.Show(); // 當 regForm 關閉時，顯示登入視窗

            regForm.Show(); // 顯示註冊視窗
        }

        // LoginForm 本身不需要特別處理例外，因為資料庫操作都在 Repository 中，其他 Form 導航也簡單
    }
}
