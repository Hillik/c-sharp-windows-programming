﻿// IUserRepository.cs
using System.Collections.Generic;

namespace MembershipSystem
{
    /// <summary>
    /// 定義會員資料操作的介面
    /// </summary>
    // [介面 (Interface)]
    public interface IUserRepository
    {
        /// <summary>
        /// 新增會員
        /// </summary>
        /// <param name="user">要新增的會員物件</param>
        /// <returns>如果成功新增則為 true，否則為 false</returns>
        bool AddUser(User user);

        /// <summary>
        /// 根據使用者名稱獲取會員物件
        /// </summary>
        /// <param name="username">使用者名稱</param>
        /// <returns>會員物件，如果找不到則為 null</returns>
        User GetUserByUsername(string username);

        /// <summary>
        /// 驗證使用者名稱和密碼
        /// </summary>
        /// <param name="username">使用者名稱</param>
        /// <param name="password">密碼</param>
        /// <returns>如果驗證成功則為 true，否則為 false</returns>
        bool ValidateUser(string username, string password);

        // 可以根據需要新增其他方法，例如 UpdateUser, DeleteUser 等
    }
}