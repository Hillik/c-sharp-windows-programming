﻿// BaseForm.cs
using System.Windows.Forms;

namespace MembershipSystem
{
    /// <summary>
    /// 所有表單的基類，包含共享功能或成員
    /// </summary>
    // [繼承 (Inheritance)] - 繼承自 System.Windows.Forms.Form
    public partial class BaseForm : Form // 使用 partial 是為了讓設計器生成的部分在另一個檔案 (.Designer.cs)
    {
        // 保護成員：子類別可以存取的使用者儲存庫實例
        // [多型 (Polymorphism)] - 使用介面型別
        protected readonly IUserRepository _userRepository;

        // 建構函式：接收一個 IUserRepository 實例
        public BaseForm(IUserRepository userRepository)
        {
            InitializeComponent(); // InitializeComponent 是 Forms 設計器自動生成的，確保 UI 元素被初始化
            _userRepository = userRepository;
        }


        // 可以添加其他共用方法，例如：
        protected void ShowErrorMessage(string message, string caption = "錯誤")
        {
            MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        protected void ShowInfoMessage(string message, string caption = "資訊")
        {
            MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}