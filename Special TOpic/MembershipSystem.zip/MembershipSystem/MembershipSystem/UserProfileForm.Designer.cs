﻿// UserProfileForm.Designer.cs
namespace MembershipSystem // 確保使用正確的 Namespace
{
    // [類別與物件 (Class and Object)] - UserProfileForm 的部分定義
    public partial class UserProfileForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblUsernameLabel = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox(); // 或者使用 Label 顯示，如果不可編輯
            this.lblEmailLabel = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox(); // 或者使用 Label 顯示
            this.lblRegistrationDateLabel = new System.Windows.Forms.Label();
            this.lblRegistrationDate = new System.Windows.Forms.Label(); // 通常只顯示，使用 Label
            this.btnClose = new System.Windows.Forms.Button(); // 關閉視窗按鈕
            // 如果支援編輯，可以新增 Save 按鈕和啟用 TextBox
            // this.btnSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            //
            // lblUsernameLabel
            //
            this.lblUsernameLabel.AutoSize = true;
            this.lblUsernameLabel.Location = new System.Drawing.Point(30, 40);
            this.lblUsernameLabel.Name = "lblUsernameLabel";
            this.lblUsernameLabel.Size = new System.Drawing.Size(82, 17);
            this.lblUsernameLabel.TabIndex = 0;
            this.lblUsernameLabel.Text = "使用者名稱:";
            //
            // txtUsername
            //
            this.txtUsername.Location = new System.Drawing.Point(150, 40);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.ReadOnly = true; // 預設為只讀
            this.txtUsername.Size = new System.Drawing.Size(150, 22);
            this.txtUsername.TabIndex = 1;
            //
            // lblEmailLabel
            //
            this.lblEmailLabel.AutoSize = true;
            this.lblEmailLabel.Location = new System.Drawing.Point(30, 80);
            this.lblEmailLabel.Name = "lblEmailLabel";
            this.lblEmailLabel.Size = new System.Drawing.Size(50, 17);
            this.lblEmailLabel.TabIndex = 2;
            this.lblEmailLabel.Text = "Email:";
            //
            // txtEmail
            //
            this.txtEmail.Location = new System.Drawing.Point(150, 80);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.ReadOnly = true; // 預設為只讀
            this.txtEmail.Size = new System.Drawing.Size(150, 22);
            this.txtEmail.TabIndex = 3;
            //
            // lblRegistrationDateLabel
            //
            this.lblRegistrationDateLabel.AutoSize = true;
            this.lblRegistrationDateLabel.Location = new System.Drawing.Point(30, 120);
            this.lblRegistrationDateLabel.Name = "lblRegistrationDateLabel";
            this.lblRegistrationDateLabel.Size = new System.Drawing.Size(82, 17);
            this.lblRegistrationDateLabel.TabIndex = 4;
            this.lblRegistrationDateLabel.Text = "註冊日期:";
            //
            // lblRegistrationDate
            //
            this.lblRegistrationDate.AutoSize = true;
            this.lblRegistrationDate.Location = new System.Drawing.Point(150, 120);
            this.lblRegistrationDate.Name = "lblRegistrationDate";
            this.lblRegistrationDate.Size = new System.Drawing.Size(100, 17); // 估計大小
            this.lblRegistrationDate.TabIndex = 5;
            this.lblRegistrationDate.Text = "[日期顯示]"; // 程式碼中設定
            //
            // btnClose
            //
            this.btnClose.Location = new System.Drawing.Point(180, 160);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(120, 30);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "關閉";
            this.btnClose.UseVisualStyleBackColor = true;
            // 事件處理函式在 UserProfileForm.cs 中
            // this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            //
            // UserProfileForm
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 220); // 調整視窗大小
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblRegistrationDate);
            this.Controls.Add(this.lblRegistrationDateLabel);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblEmailLabel);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.lblUsernameLabel);
            this.Name = "UserProfileForm";
            this.Text = "會員資料"; // 視窗標題
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        // [類別與物件 (Class and Object)] - 定義 Form 上的控制項成員
        private System.Windows.Forms.Label lblUsernameLabel; // 使用者名稱 Label (標籤)
        private System.Windows.Forms.TextBox txtUsername; // 使用者名稱 TextBox (顯示值)
        private System.Windows.Forms.Label lblEmailLabel; // Email Label (標籤)
        private System.Windows.Forms.TextBox txtEmail; // Email TextBox (顯示值)
        private System.Windows.Forms.Label lblRegistrationDateLabel; // 註冊日期 Label (標籤)
        private System.Windows.Forms.Label lblRegistrationDate; // 註冊日期 Label (顯示值)
        private System.Windows.Forms.Button btnClose; // 關閉按鈕
        // private System.Windows.Forms.Button btnSave; // 儲存按鈕 (如果支援編輯)
    }
}